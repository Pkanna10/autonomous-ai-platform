"""Benchmark: process a database dump and a query log with sqlparse.

    python bench.py           human-readable timing
    python bench.py --json    one JSON line: {"seconds": <best of 4 rounds>}

One round:
  1. split bench_data/dump.sql into statements;
  2. parse every statement and read its type;
  3. pretty-print every query of bench_data/queries.sql
     (reindent, upper-case keywords).
The reported figure is the best round.
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import sqlparse  # noqa: E402

ROUNDS = 4


def load():
    with open(os.path.join(HERE, "bench_data", "dump.sql"), encoding="utf-8") as f:
        dump = f.read()
    with open(os.path.join(HERE, "bench_data", "queries.sql"), encoding="utf-8") as f:
        queries = [line for line in f.read().splitlines() if line.strip()]
    return dump, queries


def one_round(dump, queries):
    start = time.perf_counter()
    statements = sqlparse.split(dump)
    kinds = {}
    for text in statements:
        for stmt in sqlparse.parse(text):
            kind = stmt.get_type()
            kinds[kind] = kinds.get(kind, 0) + 1
    for query in queries:
        sqlparse.format(query, reindent=True, keyword_case="upper")
    return time.perf_counter() - start, len(statements), kinds


def main():
    dump, queries = load()
    one_round(dump, queries)  # warm-up
    results = [one_round(dump, queries) for _ in range(ROUNDS)]
    best = min(r[0] for r in results)
    if "--json" in sys.argv:
        print(json.dumps({"seconds": best}))
    else:
        _, count, kinds = results[0]
        print(f"{count} statements {kinds}, {len(queries)} queries formatted: "
              f"best of {ROUNDS} rounds {best * 1000:.0f} ms")


if __name__ == "__main__":
    main()
