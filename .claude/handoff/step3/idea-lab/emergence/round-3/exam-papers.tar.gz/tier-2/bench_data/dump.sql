-- dump of the shop database
SET client_encoding = 'UTF8';
BEGIN;

CREATE TABLE IF NOT EXISTS users (
    id bigint,
    amount integer PRIMARY KEY,
    qty integer,
    kind timestamp with time zone DEFAULT 0,
    city integer DEFAULT 0,
    user_id numeric(12,2),
    name text DEFAULT 0,
    CONSTRAINT users_chk CHECK (id >= 0)
);
CREATE INDEX idx_users_amount ON users (amount, qty DESC);
COMMENT ON TABLE users IS 'holds users; one row each';

CREATE TABLE IF NOT EXISTS orders (
    name varchar(255) PRIMARY KEY,
    user_id boolean PRIMARY KEY,
    total varchar(255) PRIMARY KEY,
    sku varchar(255),
    price timestamp with time zone PRIMARY KEY,
    currency text PRIMARY KEY,
    qty varchar(255) PRIMARY KEY,
    amount integer DEFAULT 0,
    order_id boolean DEFAULT 0,
    country integer,
    note text NOT NULL,
    CONSTRAINT orders_chk CHECK (name >= 0)
);
CREATE INDEX idx_orders_user_id ON orders (user_id, total DESC);
COMMENT ON TABLE orders IS 'holds orders; one row each';

CREATE TABLE IF NOT EXISTS order_items (
    amount numeric(12,2) DEFAULT 0,
    order_id text NOT NULL,
    total bigint PRIMARY KEY,
    qty varchar(255),
    kind boolean,
    name timestamp with time zone NOT NULL,
    product_id boolean NOT NULL,
    CONSTRAINT order_items_chk CHECK (amount >= 0)
);
CREATE INDEX idx_order_items_order_id ON order_items (order_id, total DESC);
COMMENT ON TABLE order_items IS 'holds order_items; one row each';

CREATE TABLE IF NOT EXISTS products (
    kind boolean NOT NULL,
    order_id numeric(12,2) DEFAULT 0,
    amount text,
    id text DEFAULT 0,
    discount integer NOT NULL,
    country text PRIMARY KEY,
    sku varchar(255) DEFAULT 0,
    note integer DEFAULT 0,
    created_at integer PRIMARY KEY,
    email bigint NOT NULL,
    city bigint DEFAULT 0,
    CONSTRAINT products_chk CHECK (kind >= 0)
);
CREATE INDEX idx_products_order_id ON products (order_id, amount DESC);
COMMENT ON TABLE products IS 'holds products; one row each';

CREATE TABLE IF NOT EXISTS inventory (
    user_id timestamp with time zone PRIMARY KEY,
    created_at bigint DEFAULT 0,
    order_id integer PRIMARY KEY,
    price bigint,
    note varchar(255),
    name timestamp with time zone NOT NULL,
    country boolean DEFAULT 0,
    currency text DEFAULT 0,
    CONSTRAINT inventory_chk CHECK (user_id >= 0)
);
CREATE INDEX idx_inventory_created_at ON inventory (created_at, order_id DESC);
COMMENT ON TABLE inventory IS 'holds inventory; one row each';

CREATE TABLE IF NOT EXISTS payments (
    email timestamp with time zone NOT NULL,
    updated_at bigint,
    currency text,
    discount text DEFAULT 0,
    status numeric(12,2) DEFAULT 0,
    kind integer NOT NULL,
    price timestamp with time zone,
    created_at text PRIMARY KEY,
    id text PRIMARY KEY,
    name integer PRIMARY KEY,
    total bigint,
    note boolean NOT NULL,
    CONSTRAINT payments_chk CHECK (email >= 0)
);
CREATE INDEX idx_payments_updated_at ON payments (updated_at, currency DESC);
COMMENT ON TABLE payments IS 'holds payments; one row each';

CREATE TABLE IF NOT EXISTS refunds (
    status integer,
    country boolean,
    product_id integer DEFAULT 0,
    note varchar(255) NOT NULL,
    amount timestamp with time zone NOT NULL,
    kind timestamp with time zone NOT NULL,
    email text NOT NULL,
    id numeric(12,2) DEFAULT 0,
    name bigint DEFAULT 0,
    CONSTRAINT refunds_chk CHECK (status >= 0)
);
CREATE INDEX idx_refunds_country ON refunds (country, product_id DESC);
COMMENT ON TABLE refunds IS 'holds refunds; one row each';

CREATE TABLE IF NOT EXISTS shipments (
    currency numeric(12,2) DEFAULT 0,
    total integer NOT NULL,
    product_id varchar(255) NOT NULL,
    note text,
    amount text,
    name timestamp with time zone,
    email bigint PRIMARY KEY,
    created_at boolean,
    country integer PRIMARY KEY,
    CONSTRAINT shipments_chk CHECK (currency >= 0)
);
CREATE INDEX idx_shipments_total ON shipments (total, product_id DESC);
COMMENT ON TABLE shipments IS 'holds shipments; one row each';

CREATE TABLE IF NOT EXISTS carriers (
    kind varchar(255) NOT NULL,
    created_at timestamp with time zone PRIMARY KEY,
    discount numeric(12,2) DEFAULT 0,
    qty bigint,
    status numeric(12,2),
    id boolean DEFAULT 0,
    total timestamp with time zone,
    email boolean DEFAULT 0,
    sku bigint NOT NULL,
    name text,
    CONSTRAINT carriers_chk CHECK (kind >= 0)
);
CREATE INDEX idx_carriers_created_at ON carriers (created_at, discount DESC);
COMMENT ON TABLE carriers IS 'holds carriers; one row each';

CREATE TABLE IF NOT EXISTS addresses (
    id bigint DEFAULT 0,
    created_at integer,
    qty varchar(255) PRIMARY KEY,
    total boolean DEFAULT 0,
    currency boolean NOT NULL,
    order_id boolean,
    CONSTRAINT addresses_chk CHECK (id >= 0)
);
CREATE INDEX idx_addresses_created_at ON addresses (created_at, qty DESC);
COMMENT ON TABLE addresses IS 'holds addresses; one row each';

CREATE TABLE IF NOT EXISTS sessions (
    product_id text NOT NULL,
    email text DEFAULT 0,
    updated_at text PRIMARY KEY,
    country text DEFAULT 0,
    amount bigint DEFAULT 0,
    city boolean DEFAULT 0,
    qty boolean NOT NULL,
    note varchar(255) DEFAULT 0,
    CONSTRAINT sessions_chk CHECK (product_id >= 0)
);
CREATE INDEX idx_sessions_email ON sessions (email, updated_at DESC);
COMMENT ON TABLE sessions IS 'holds sessions; one row each';

CREATE TABLE IF NOT EXISTS events (
    country integer,
    amount integer DEFAULT 0,
    sku integer,
    city boolean PRIMARY KEY,
    order_id text DEFAULT 0,
    discount text DEFAULT 0,
    product_id timestamp with time zone DEFAULT 0,
    currency bigint DEFAULT 0,
    id varchar(255) NOT NULL,
    price bigint PRIMARY KEY,
    name text,
    CONSTRAINT events_chk CHECK (country >= 0)
);
CREATE INDEX idx_events_amount ON events (amount, sku DESC);
COMMENT ON TABLE events IS 'holds events; one row each';

CREATE TABLE IF NOT EXISTS audit_log (
    order_id numeric(12,2) DEFAULT 0,
    qty numeric(12,2) NOT NULL,
    city text PRIMARY KEY,
    email text DEFAULT 0,
    amount integer,
    CONSTRAINT audit_log_chk CHECK (order_id >= 0)
);
CREATE INDEX idx_audit_log_qty ON audit_log (qty, city DESC);
COMMENT ON TABLE audit_log IS 'holds audit_log; one row each';

CREATE TABLE IF NOT EXISTS coupons (
    note numeric(12,2) PRIMARY KEY,
    city varchar(255) DEFAULT 0,
    discount text NOT NULL,
    email timestamp with time zone,
    id numeric(12,2) DEFAULT 0,
    sku numeric(12,2) DEFAULT 0,
    status numeric(12,2),
    country bigint,
    kind bigint NOT NULL,
    amount boolean NOT NULL,
    name text NOT NULL,
    CONSTRAINT coupons_chk CHECK (note >= 0)
);
CREATE INDEX idx_coupons_city ON coupons (city, discount DESC);
COMMENT ON TABLE coupons IS 'holds coupons; one row each';

CREATE TABLE IF NOT EXISTS reviews (
    order_id varchar(255) DEFAULT 0,
    status bigint PRIMARY KEY,
    country numeric(12,2) NOT NULL,
    kind text DEFAULT 0,
    email boolean NOT NULL,
    id text NOT NULL,
    city timestamp with time zone DEFAULT 0,
    price text,
    updated_at numeric(12,2) DEFAULT 0,
    total bigint,
    amount bigint DEFAULT 0,
    CONSTRAINT reviews_chk CHECK (order_id >= 0)
);
CREATE INDEX idx_reviews_status ON reviews (status, country DESC);
COMMENT ON TABLE reviews IS 'holds reviews; one row each';

CREATE TABLE IF NOT EXISTS categories (
    id text NOT NULL,
    email boolean,
    status timestamp with time zone,
    amount numeric(12,2) PRIMARY KEY,
    discount boolean DEFAULT 0,
    qty bigint NOT NULL,
    currency timestamp with time zone DEFAULT 0,
    name integer,
    CONSTRAINT categories_chk CHECK (id >= 0)
);
CREATE INDEX idx_categories_email ON categories (email, status DESC);
COMMENT ON TABLE categories IS 'holds categories; one row each';

CREATE TABLE IF NOT EXISTS suppliers (
    created_at integer,
    product_id text NOT NULL,
    user_id numeric(12,2) PRIMARY KEY,
    price numeric(12,2) NOT NULL,
    currency integer,
    qty numeric(12,2) NOT NULL,
    amount varchar(255) PRIMARY KEY,
    name timestamp with time zone,
    id numeric(12,2) DEFAULT 0,
    city bigint PRIMARY KEY,
    kind integer PRIMARY KEY,
    total timestamp with time zone DEFAULT 0,
    CONSTRAINT suppliers_chk CHECK (created_at >= 0)
);
CREATE INDEX idx_suppliers_product_id ON suppliers (product_id, user_id DESC);
COMMENT ON TABLE suppliers IS 'holds suppliers; one row each';

CREATE TABLE IF NOT EXISTS warehouses (
    price boolean DEFAULT 0,
    kind bigint NOT NULL,
    updated_at integer,
    qty integer DEFAULT 0,
    discount numeric(12,2) PRIMARY KEY,
    currency timestamp with time zone NOT NULL,
    product_id numeric(12,2),
    id numeric(12,2) DEFAULT 0,
    status timestamp with time zone DEFAULT 0,
    created_at text DEFAULT 0,
    note boolean NOT NULL,
    CONSTRAINT warehouses_chk CHECK (price >= 0)
);
CREATE INDEX idx_warehouses_kind ON warehouses (kind, updated_at DESC);
COMMENT ON TABLE warehouses IS 'holds warehouses; one row each';

CREATE TABLE IF NOT EXISTS invoices (
    sku timestamp with time zone DEFAULT 0,
    user_id numeric(12,2),
    price bigint NOT NULL,
    order_id bigint NOT NULL,
    amount boolean PRIMARY KEY,
    currency integer DEFAULT 0,
    kind boolean PRIMARY KEY,
    total timestamp with time zone,
    CONSTRAINT invoices_chk CHECK (sku >= 0)
);
CREATE INDEX idx_invoices_user_id ON invoices (user_id, price DESC);
COMMENT ON TABLE invoices IS 'holds invoices; one row each';

CREATE TABLE IF NOT EXISTS subscriptions (
    note numeric(12,2) DEFAULT 0,
    order_id timestamp with time zone NOT NULL,
    discount bigint,
    updated_at boolean,
    created_at integer DEFAULT 0,
    currency boolean NOT NULL,
    sku text,
    product_id numeric(12,2) DEFAULT 0,
    name integer PRIMARY KEY,
    CONSTRAINT subscriptions_chk CHECK (note >= 0)
);
CREATE INDEX idx_subscriptions_order_id ON subscriptions (order_id, discount DESC);
COMMENT ON TABLE subscriptions IS 'holds subscriptions; one row each';

/* bulk load for users */
INSERT INTO users (order_id, updated_at, discount, price, id, city, country) VALUES
  ('shipped', 'O''Brien', '--not a comment', NULL, '--not a comment', 'x@example.com', 'O''Brien'),
  ('EUR', '2026-01-07', 34768, '--not a comment', 85844, NULL, TRUE),
  (TRUE, NULL, 'line; with semicolon', '2026-01-05', 71579, '--not a comment', 45220),
  (877.97, 31333, 'O''Brien', NULL, 'pending', 68929, 'pending'),
  ('O''Brien', 87769, NULL, 207.21, 68502, DEFAULT, 'x@example.com'),
  ('x@example.com', 'O''Brien', 43336, 43.58, 'pending', 62734, 69.59),
  ('x@example.com', 93092, 20270, 99593, 72754, 27205, 5711),
  ('EUR', 48137, 75054, 524.78, 'pending', 94089, NULL),
  (NULL, NULL, 1238, 33118, 'a b c', 823.90, 728.88),
  ('EUR', 80235, 576, 84617, 'EUR', FALSE, 'x@example.com'),
  (23985, NULL, '--not a comment', 56985, 70341, 154.68, 'pending'),
  (53868, TRUE, 750.57, 'line; with semicolon', 'shipped', 'O''Brien', 'O''Brien'),
  ('EUR', 'x@example.com', 15175, 'pending', 54075, 'x@example.com', 57520),
  (83237, 18166, 21.07, 93168, 39127, DEFAULT, 30919),
  (NULL, 96962, 98749, 25592, 'line; with semicolon', 'shipped', 'a b c'),
  (75.47, '--not a comment', 19710, NULL, 'a b c', 16947, 315.26),
  ('--not a comment', 'pending', now(), 'O''Brien', 97681, 30174, '2026-01-07'),
  (TRUE, 30575, 71749, TRUE, 25605, 368.32, FALSE),
  (82427, DEFAULT, 76158, 643.77, FALSE, 'shipped', 125.49),
  (42215, '--not a comment', 39071, 'O''Brien', 45794, '--not a comment', 'line; with semicolon'),
  (now(), 'line; with semicolon', 'x@example.com', 'line; with semicolon', '2026-01-06', NULL, 778.28),
  (now(), NULL, 'line; with semicolon', 'line; with semicolon', FALSE, NULL, 582.15),
  ('x@example.com', NULL, 87274, 'pending', 'shipped', 722.19, 370.03),
  (NULL, '--not a comment', 79619, DEFAULT, '2026-01-09', 10092, 'pending'),
  ('a b c', 48141, 'a b c', 'line; with semicolon', 7846, 91633, 90893),
  (643.64, 'x@example.com', 960.37, 513.60, 50286, 938.13, FALSE),
  (NULL, 33612, 'O''Brien', now(), 49427, 14599, 'EUR'),
  (96522, 'shipped', 40802, 'O''Brien', 85426, 84756, 'a b c'),
  ('2026-01-07', '2026-01-05', 27800, 'EUR', 42008, 305.50, NULL),
  (170.26, DEFAULT, '2026-01-08', 7656, now(), TRUE, 'a b c'),
  (722.41, 'a b c', NULL, 46126, 'EUR', 'pending', 'shipped'),
  (70030, 'O''Brien', NULL, 79207, 50518, TRUE, 'a b c'),
  ('2026-01-05', '2026-01-09', 72.69, 656.61, 'EUR', 19938, NULL),
  (18593, 1468, 'EUR', '2026-01-08', 86135, TRUE, 'O''Brien'),
  (56833, 'O''Brien', '2026-01-04', 41752, 555.68, 'pending', FALSE),
  ('a b c', NULL, 91046, 'shipped', '2026-01-05', 'EUR', 297.99),
  ('EUR', 460.93, '2026-01-07', 571.40, 122.80, 30953, 209.54),
  ('O''Brien', TRUE, now(), 'pending', 567.04, 40228, NULL),
  (93121, 'EUR', 'pending', 85989, NULL, 87159, TRUE),
  (52.89, NULL, 'line; with semicolon', 18411, DEFAULT, NULL, 40793),
  (97212, 'line; with semicolon', 'a b c', NULL, 38277, 'a b c', 91.87),
  ('a b c', 37501, 915.16, 'a b c', DEFAULT, 'EUR', now()),
  (NULL, 24988, 14301, 844.42, 9509, 'EUR', 89470),
  (61172, 'x@example.com', 97461, NULL, FALSE, 89897, 'a b c'),
  (NULL, '--not a comment', 20732, now(), 'EUR', 'shipped', 32957),
  (80901, '--not a comment', 'line; with semicolon', 310.28, 'line; with semicolon', 'pending', '--not a comment'),
  (now(), 'shipped', DEFAULT, '--not a comment', 15598, 60976, 41689),
  ('pending', DEFAULT, 148.22, 16262, 95204, 675.02, 466.60),
  ('line; with semicolon', 'O''Brien', NULL, 'EUR', 41767, 'a b c', 495.70),
  (16221, NULL, 2024, 711, 137.90, FALSE, '--not a comment'),
  ('--not a comment', NULL, NULL, 255.83, NULL, 'line; with semicolon', '--not a comment'),
  (TRUE, 70697, NULL, NULL, 65818, '--not a comment', 6975),
  (89140, 89536, 470.42, 'line; with semicolon', 258.87, FALSE, NULL),
  ('--not a comment', NULL, now(), 47527, 29731, 'EUR', 60387),
  (22152, 10330, NULL, 79598, 370.48, 76297, 3242),
  (96805, 81907, 'O''Brien', 12493, 'a b c', 35919, 2903),
  ('O''Brien', 'a b c', 65157, 'pending', 'pending', NULL, 'x@example.com'),
  ('a b c', 'EUR', 22624, DEFAULT, NULL, 18352, 10529),
  ('O''Brien', '2026-01-07', NULL, 50099, now(), 27777, 'a b c'),
  (83857, 'O''Brien', 76500, 903.32, NULL, FALSE, 68488),
  (98741, '2026-01-01', 69545, 'EUR', 66182, 'EUR', 24305),
  ('O''Brien', 'EUR', 93254, 'line; with semicolon', 35968, 312.95, NULL),
  ('shipped', 71283, 'O''Brien', 'a b c', 'shipped', '--not a comment', NULL),
  (TRUE, 54594, 'pending', NULL, 'pending', NULL, 42.22),
  (now(), NULL, 762.50, 648.62, TRUE, 48404, 'pending'),
  (NULL, '2026-01-08', 514.71, 'pending', now(), 277.95, 94814),
  ('--not a comment', 'pending', NULL, NULL, NULL, '2026-01-07', 'EUR'),
  ('a b c', 'shipped', NULL, TRUE, 394.24, '--not a comment', 40098),
  ('--not a comment', 55647, '--not a comment', 121.01, now(), 'EUR', 68668),
  (NULL, 157.75, '2026-01-04', 44525, 97940, 'EUR', 717.92),
  (35854, now(), 'line; with semicolon', NULL, 820.78, '2026-01-06', 336.33),
  (NULL, 586.65, DEFAULT, 75500, 869.10, '2026-01-02', 77053),
  (65279, 39375, 'line; with semicolon', 98108, 'x@example.com', 43798, 'shipped'),
  (388.19, now(), 53.67, FALSE, 'a b c', 'EUR', NULL),
  ('--not a comment', 'O''Brien', DEFAULT, 460.89, NULL, 521, 5562),
  (947.97, 'EUR', 'x@example.com', 'a b c', 181.31, 'EUR', 41298),
  ('a b c', 75421, 56908, 35852, 18734, 'shipped', 'a b c'),
  ('O''Brien', now(), NULL, '2026-01-08', NULL, TRUE, 48182),
  (41.28, 'shipped', 'line; with semicolon', 'O''Brien', now(), '--not a comment', 660.75),
  (57684, 290.55, 71341, 'EUR', NULL, 'EUR', 80670),
  ('a b c', 'x@example.com', 25271, DEFAULT, 'a b c', 'x@example.com', 972.63),
  (77140, '--not a comment', 'EUR', DEFAULT, 'EUR', 851.33, 38165),
  (728.40, 526.09, 24459, 22357, FALSE, 'EUR', 51321),
  ('a b c', 'a b c', 'pending', 'shipped', 510.07, 49173, 56112),
  ('pending', NULL, 'pending', 'EUR', 774.08, 'shipped', now()),
  (36544, DEFAULT, 10606, 755.09, now(), 94027, 'pending'),
  (76669, 39240, DEFAULT, NULL, 'line; with semicolon', 41329, 53377),
  (186.81, '--not a comment', 34367, '2026-01-04', FALSE, TRUE, 'shipped'),
  (551.99, NULL, 3157, '--not a comment', 'EUR', 'EUR', 792.73),
  (FALSE, 'EUR', 864.32, 'shipped', 26339, 99750, NULL),
  ('line; with semicolon', 411.89, NULL, 'line; with semicolon', 72306, 7733, TRUE),
  (TRUE, now(), 'EUR', 11480, 752.21, 79506, NULL),
  (471.68, DEFAULT, 78381, 52688, 89238, 'line; with semicolon', 389.61),
  (59061, 23200, '2026-01-03', 67949, 30016, 23008, 121.59),
  ('2026-01-08', 'EUR', 29394, 63977, DEFAULT, TRUE, 'shipped'),
  (879.31, 38031, 'x@example.com', DEFAULT, 1041, 47395, NULL),
  ('O''Brien', NULL, 73492, '--not a comment', 17946, 73547, 740.86),
  ('pending', 'x@example.com', 'O''Brien', TRUE, 82693, 40061, NULL),
  (62266, 55786, TRUE, 68968, FALSE, 'x@example.com', now()),
  (477.61, 'pending', 233.06, 899.56, 545.37, NULL, 79733),
  (NULL, 10773, NULL, NULL, 47336, 88529, NULL),
  ('x@example.com', NULL, 15597, 229.17, 83952, 737.50, 30597),
  (390.41, 21351, 52775, 479.62, 'EUR', 'shipped', 76131),
  (52049, 551.12, 'a b c', 96146, 91801, 95280, 'x@example.com'),
  ('x@example.com', FALSE, NULL, '2026-01-01', 'EUR', 11.53, DEFAULT),
  (927.55, 328.44, NULL, 91348, 67722, 'x@example.com', NULL),
  ('EUR', 'pending', 31784, 97614, 893.48, 'O''Brien', 740.80),
  (50955, 'line; with semicolon', 'shipped', 975.38, 721.39, 845.31, now()),
  ('O''Brien', 'shipped', '2026-01-04', 'line; with semicolon', 765.50, 30.63, DEFAULT),
  ('line; with semicolon', 21150, 'x@example.com', 'a b c', 'x@example.com', 28038, 36736),
  ('2026-01-04', 11905, 'EUR', 36025, NULL, 'line; with semicolon', 39538),
  (5458, '2026-01-03', NULL, 'EUR', NULL, 655.67, 241.13),
  (DEFAULT, 'pending', 27709, 54102, '--not a comment', '2026-01-09', NULL),
  ('EUR', '2026-01-02', 'pending', 59609, 'a b c', FALSE, 55311),
  (21369, 'pending', 'a b c', 84587, NULL, 46398, 'EUR'),
  (now(), 672.96, NULL, 'pending', 26852, NULL, now()),
  (NULL, 31008, NULL, '--not a comment', 'O''Brien', NULL, '2026-01-05'),
  (4032, 148.93, 4791, 'x@example.com', 'pending', 'EUR', 4168),
  ('2026-01-05', 674.33, 'pending', 'line; with semicolon', 22953, NULL, TRUE),
  (149.79, 28371, NULL, 'x@example.com', 30806, '2026-01-06', FALSE),
  (636.54, 839.13, 'a b c', DEFAULT, NULL, 74432, '--not a comment'),
  (420.56, 47305, 619.34, NULL, 228.29, 'x@example.com', 70268),
  ('a b c', 342.32, 'a b c', 59273, NULL, now(), 'O''Brien'),
  (636.36, NULL, 43962, 96438, DEFAULT, NULL, 41703),
  ('O''Brien', FALSE, NULL, '2026-01-04', 23823, NULL, 26489),
  ('EUR', 'EUR', 65685, 82302, 11583, NULL, 33.00),
  ('2026-01-05', 822.06, 829.43, 'pending', '--not a comment', 47187, 'line; with semicolon'),
  ('EUR', NULL, 'line; with semicolon', '2026-01-02', 59542, 19718, DEFAULT),
  (17556, NULL, 'pending', '2026-01-06', 57265, NULL, 452.16),
  ('2026-01-05', 92302, 'pending', 63428, 'shipped', 56323, 673.64),
  ('x@example.com', 69722, 279.33, NULL, 'shipped', '--not a comment', 69504),
  ('line; with semicolon', '2026-01-06', 'x@example.com', 'x@example.com', 86640, NULL, 278.77),
  ('shipped', 'x@example.com', 'line; with semicolon', 43453, 508.48, NULL, 'shipped'),
  (TRUE, 'line; with semicolon', 509.89, 78632, 'line; with semicolon', 88024, 'shipped'),
  ('shipped', 68.67, 66956, 'EUR', 77839, 341.60, 'x@example.com'),
  ('EUR', 232.61, NULL, 'EUR', 18323, NULL, 49725),
  (33786, 'a b c', '2026-01-07', 593.19, 24857, 'line; with semicolon', NULL),
  ('line; with semicolon', TRUE, 831.81, '--not a comment', FALSE, NULL, '--not a comment'),
  ('2026-01-03', 133.41, 15753, NULL, 233.33, 'shipped', NULL),
  (FALSE, 622.41, now(), 'pending', 43756, '--not a comment', 13724),
  ('line; with semicolon', 61414, 610.15, '2026-01-09', 78.49, 59704, TRUE),
  (32759, FALSE, '2026-01-03', 947.59, 'a b c', 'a b c', 55089),
  (88176, now(), 'pending', 368.78, 'shipped', 'pending', 430.18),
  ('2026-01-05', 54157, NULL, '--not a comment', 'a b c', 'x@example.com', 'shipped'),
  (50681, 'shipped', 11948, 4377, 49960, 'pending', 776.80),
  (NULL, 956.18, 15015, NULL, TRUE, 11988, 11090),
  (NULL, NULL, 375, 72105, 88731, 835.86, '2026-01-06'),
  (372.54, 10543, '--not a comment', '2026-01-07', DEFAULT, 'line; with semicolon', 903.70),
  (99.05, 43370, 'line; with semicolon', 49420, 497.66, '2026-01-08', 69767),
  (65286, '--not a comment', 104.50, '--not a comment', 'pending', 96656, 98205),
  ('line; with semicolon', '--not a comment', 'x@example.com', NULL, NULL, 530.44, 65662),
  (82516, NULL, 96758, DEFAULT, 220.96, 28567, 8487),
  (94570, 'pending', 739.89, 31120, 'shipped', 'x@example.com', 36032),
  (282.50, NULL, 'x@example.com', 'O''Brien', 'line; with semicolon', 9256, now()),
  (273.44, 132.29, 'pending', 94367, NULL, TRUE, NULL),
  ('a b c', 13855, TRUE, 'pending', 'EUR', 96078, 'shipped'),
  (17010, 'pending', '--not a comment', 47528, 14305, 39714, 'a b c'),
  ('O''Brien', 292.28, 85392, 55794, FALSE, NULL, 878.20),
  (DEFAULT, 'shipped', '--not a comment', 'a b c', 'shipped', 'x@example.com', 10441),
  (18588, 'a b c', NULL, 295.97, 971.22, 44378, 'line; with semicolon'),
  ('a b c', 2491, 192.22, 45877, 88480, NULL, 39647),
  (61813, 144.69, 54579, 278.47, DEFAULT, now(), NULL),
  (646.99, DEFAULT, TRUE, 'O''Brien', 68713, NULL, 'O''Brien'),
  (NULL, 42204, 888.76, 52032, NULL, FALSE, 55378),
  (58785, 'a b c', 'pending', '2026-01-02', 'line; with semicolon', NULL, 'EUR'),
  ('2026-01-04', 'x@example.com', 'x@example.com', 47098, 'EUR', 'O''Brien', 613.73),
  ('a b c', 21587, 673.56, 'EUR', 77475, 'O''Brien', 748.19),
  (DEFAULT, 46520, 9431, 58611, NULL, 'x@example.com', 14701),
  ('EUR', 'EUR', 14116, 17934, 'x@example.com', 71286, NULL),
  ('--not a comment', NULL, 'a b c', 'EUR', 30911, 52327, 85536),
  (81508, 64656, 'O''Brien', FALSE, 'a b c', 99291, 43613),
  (NULL, NULL, '--not a comment', 866.24, 854.08, 34768, 'pending'),
  (3898, '2026-01-06', 16782, 'pending', now(), DEFAULT, DEFAULT),
  ('a b c', now(), now(), 27036, 'x@example.com', NULL, NULL),
  (NULL, 34211, 19950, 'pending', DEFAULT, 97.99, DEFAULT),
  (89766, 245.49, 526.05, 66609, 'a b c', 77848, 423.36),
  ('O''Brien', 'shipped', '--not a comment', 673.95, 75517, 807.48, 997.36),
  (98678, 22482, 17779, 56312, NULL, 75244, 875.33),
  ('--not a comment', now(), 98791, 3827, 40783, 16370, FALSE),
  ('--not a comment', TRUE, 'x@example.com', 'pending', 'line; with semicolon', 407.72, 110.67),
  (401.93, 'pending', 'pending', 40632, 162.56, 610.98, '--not a comment'),
  (44993, NULL, 'EUR', NULL, FALSE, 'O''Brien', 732.91),
  ('O''Brien', TRUE, NULL, 47190, 23938, 713.84, 92083),
  (TRUE, 61802, 638.88, 75521, 43152, NULL, 99551),
  (NULL, FALSE, 81140, TRUE, 789.69, 82692, 'shipped'),
  (44660, 'O''Brien', NULL, 71631, NULL, 98870, 'O''Brien'),
  (NULL, DEFAULT, 87285, 'pending', NULL, 192.96, 62383),
  (793.77, '--not a comment', 35412, 448.93, NULL, 'EUR', '--not a comment'),
  (20422, 248.31, 25390, 'shipped', NULL, FALSE, 43779),
  (682.33, 25712, 37569, now(), 95068, '--not a comment', NULL),
  (98744, NULL, 55714, 'a b c', NULL, 529.04, 2265),
  (72384, 422.32, '--not a comment', 'shipped', 429.50, 95346, 4390),
  (30.46, FALSE, 59223, 97415, '--not a comment', 76922, 17506),
  (119.89, 65.21, 36419, 99873, 'a b c', 'line; with semicolon', 'shipped'),
  (264.13, 'x@example.com', 'shipped', 347.89, '--not a comment', 'a b c', 79517),
  ('shipped', 249.92, 19690, 91485, 90550, '--not a comment', 61243),
  (57577, 3434, 'EUR', DEFAULT, 'O''Brien', 98062, 89742),
  (40519, 'x@example.com', 139, 31411, 'shipped', 50418, 970.84),
  (NULL, 67.03, 'x@example.com', 'O''Brien', TRUE, 26845, 'line; with semicolon'),
  ('O''Brien', 'a b c', 994.58, 428.74, NULL, 'EUR', 'x@example.com'),
  (17163, 223.81, 'shipped', 'x@example.com', 25569, 'pending', TRUE),
  (664.96, 'a b c', 37421, 543.31, TRUE, NULL, NULL),
  (88973, 85984, 50546, 783.82, '2026-01-09', 73786, NULL),
  (45069, 'line; with semicolon', 267.25, FALSE, NULL, 819.10, TRUE),
  ('2026-01-08', '2026-01-06', 53095, 24600, 33386, NULL, '--not a comment'),
  ('EUR', 103.54, 57147, 'line; with semicolon', 71948, NULL, NULL),
  (DEFAULT, '--not a comment', NULL, 3154, 511.60, NULL, 49625),
  (DEFAULT, 182.88, 42831, 'a b c', 'x@example.com', 582.05, 'x@example.com'),
  (NULL, '2026-01-05', 'O''Brien', 52986, 'line; with semicolon', FALSE, 'pending'),
  (673.88, 376.93, 'a b c', 984.78, 'a b c', DEFAULT, 22102),
  ('--not a comment', 986.58, NULL, 'pending', DEFAULT, 218.05, 'line; with semicolon'),
  (DEFAULT, 95710, '--not a comment', 505.50, 66968, 'x@example.com', 'shipped'),
  ('x@example.com', 181.52, NULL, 674.49, 'line; with semicolon', 'shipped', 79917),
  (4603, 50734, '--not a comment', 'O''Brien', 'O''Brien', 14270, DEFAULT),
  ('--not a comment', 11537, 'EUR', NULL, 44239, 947.43, 'O''Brien'),
  ('--not a comment', 52064, 'EUR', 'line; with semicolon', 53438, 'a b c', now()),
  ('line; with semicolon', 85290, 'EUR', 'a b c', 72773, 'a b c', 'O''Brien'),
  (62447, TRUE, 'O''Brien', '2026-01-02', NULL, 23251, 'a b c'),
  (59814, 84838, 67329, 'a b c', 18902, 92032, 'line; with semicolon'),
  (32706, 42553, 'O''Brien', NULL, 'x@example.com', 'EUR', 'line; with semicolon'),
  (60172, NULL, 337.04, NULL, DEFAULT, 71236, 'x@example.com'),
  ('pending', 202.47, 761.93, NULL, 36592, 117.97, 'shipped'),
  (55942, 6209, now(), 'shipped', 160.13, 395.73, 'a b c'),
  (900.33, NULL, 'x@example.com', 876.78, 'EUR', now(), '--not a comment'),
  (TRUE, 16155, DEFAULT, 48085, 'pending', 'a b c', 9168),
  (19007, 99.89, 30986, 'pending', 261.01, NULL, NULL),
  ('2026-01-07', 613.96, 258.37, 574.58, 'a b c', NULL, 'pending'),
  (TRUE, 98496, 'shipped', 'O''Brien', 46388, TRUE, 91362),
  (NULL, 'O''Brien', 191.98, 'EUR', 16575, 67366, 429.36),
  (47997, 'EUR', 'x@example.com', 64887, 99831, 620.47, DEFAULT),
  (FALSE, 'a b c', NULL, 'EUR', 'O''Brien', NULL, 'x@example.com'),
  (NULL, now(), '2026-01-07', 'EUR', NULL, DEFAULT, 'shipped'),
  (63591, '2026-01-06', NULL, NULL, FALSE, 86962, now()),
  (41655, 155.60, 66368, 163.60, 135.63, 96042, 'a b c'),
  ('a b c', 65645, 158.54, 17436, 27789, TRUE, 'shipped'),
  (82266, 5084, TRUE, 'O''Brien', 79196, 92750, NULL),
  ('O''Brien', 66903, 781.13, TRUE, 16664, 51350, 69240),
  (NULL, 94713, 'line; with semicolon', 'EUR', 'pending', TRUE, 57564),
  ('--not a comment', '2026-01-03', 'line; with semicolon', 'O''Brien', 'shipped', TRUE, 93848),
  ('x@example.com', 938.09, 38725, 46781, '2026-01-08', 54089, 'x@example.com'),
  (749.00, 'pending', 877.42, '2026-01-03', 'EUR', FALSE, 66811),
  (TRUE, NULL, NULL, 892.99, 'EUR', 21066, 'EUR');

/* bulk load for orders */
INSERT INTO orders (user_id, amount, price, name, currency) VALUES
  ('line; with semicolon', 'shipped', NULL, 44743, 72859),
  (5430, 84451, 57538, 'EUR', 977.00),
  (52931, 36239, 'EUR', NULL, DEFAULT),
  ('O''Brien', 319.85, 'EUR', '2026-01-08', 539.68),
  (791.12, 88899, 545.27, 218.06, DEFAULT),
  (16048, 'line; with semicolon', 'line; with semicolon', 683.76, '--not a comment'),
  ('O''Brien', NULL, 'a b c', '--not a comment', 742),
  (4.94, 'pending', 33559, 'EUR', 51990),
  (17752, 47517, 623.29, 'pending', 13610),
  (19339, NULL, 423.60, '--not a comment', 582),
  (93220, 32334, 97976, 28266, '2026-01-02'),
  ('shipped', 33344, NULL, 'shipped', 53278),
  ('line; with semicolon', 'O''Brien', 'O''Brien', NULL, 57659),
  (now(), NULL, now(), 14306, 74.51),
  (now(), 'pending', NULL, 'a b c', 386.90),
  (NULL, 20679, 83118, NULL, 'pending'),
  (177.50, 709.82, 'EUR', '2026-01-03', 92354),
  (57.76, 156.31, now(), 44523, 644.11),
  ('EUR', 'shipped', 'shipped', 736.93, 76931),
  (58342, NULL, 68100, 'pending', NULL),
  (9004, 'line; with semicolon', 85399, 97633, NULL),
  ('pending', 54878, '--not a comment', 4701, 12.28),
  (60966, NULL, 2475, 'a b c', 'a b c'),
  ('O''Brien', 5262, 'a b c', 527.65, 17266),
  (NULL, NULL, DEFAULT, 62846, 'EUR'),
  (32706, 'pending', 'a b c', 'x@example.com', NULL),
  (NULL, 32937, 'EUR', NULL, 52407),
  (now(), 809.43, 'shipped', 'O''Brien', 'pending'),
  (69634, 'EUR', 634.41, '--not a comment', 22789),
  (NULL, 'line; with semicolon', TRUE, 13394, 41.84),
  (15791, 'a b c', TRUE, 9751, NULL),
  ('a b c', 'pending', 'line; with semicolon', 'line; with semicolon', 74082),
  (28690, 143.12, '--not a comment', 46941, 844.28),
  (now(), DEFAULT, TRUE, 'a b c', now()),
  ('x@example.com', 'a b c', 'shipped', NULL, now()),
  ('line; with semicolon', 'pending', 352.27, DEFAULT, FALSE),
  ('x@example.com', 121.81, 22043, 'pending', '2026-01-09'),
  (NULL, FALSE, 27444, NULL, FALSE),
  (FALSE, 'a b c', 49389, 378.82, 49101),
  (17848, 'line; with semicolon', 'x@example.com', NULL, 374.48),
  (NULL, 84021, NULL, NULL, 'line; with semicolon'),
  (80952, 53532, 766.32, NULL, 'a b c'),
  (52945, 885.50, '2026-01-05', 31407, 'pending'),
  (802.57, 31909, 470.49, NULL, 'line; with semicolon'),
  (822.94, '2026-01-08', 814.23, 'EUR', 58975),
  (13283, 80090, 'x@example.com', 'shipped', NULL),
  (FALSE, 99376, 46992, now(), 'pending'),
  (NULL, 22946, 'x@example.com', 524.56, TRUE),
  ('line; with semicolon', 'x@example.com', TRUE, 96899, 58181),
  (NULL, 'EUR', TRUE, 105.09, 323.52),
  (NULL, 58657, 52372, 'pending', 'EUR'),
  ('line; with semicolon', 'EUR', FALSE, 17428, 18309),
  (90658, NULL, 49690, 'pending', 31049),
  (now(), DEFAULT, '2026-01-02', 'shipped', '--not a comment'),
  (909.45, NULL, 43281, '--not a comment', 'x@example.com'),
  ('pending', 23.06, 'EUR', NULL, 'pending'),
  (219.57, 'O''Brien', NULL, '--not a comment', 54824),
  (734.49, FALSE, 81900, '2026-01-07', 65535),
  (24429, DEFAULT, 24522, 51051, 83968),
  ('pending', 68219, '2026-01-09', 'EUR', 'EUR'),
  ('2026-01-06', 'EUR', '2026-01-09', 'x@example.com', '2026-01-01'),
  ('x@example.com', 60107, 158.96, 48258, 'shipped'),
  ('EUR', 'pending', 927.26, 52336, DEFAULT),
  (7836, 110.71, 51762, 'x@example.com', '--not a comment'),
  (62802, 'O''Brien', 33759, 'line; with semicolon', '--not a comment'),
  ('a b c', 'line; with semicolon', 657.12, 'EUR', now()),
  (70368, 'EUR', 'x@example.com', 56359, 'O''Brien'),
  (31959, NULL, 'shipped', 12893, 'O''Brien'),
  ('line; with semicolon', 'O''Brien', 19015, NULL, 104.77),
  (223.62, 'EUR', 'O''Brien', 'O''Brien', 46703),
  (DEFAULT, 55901, 'pending', 590, '--not a comment'),
  (10332, 82913, NULL, 83020, NULL),
  ('x@example.com', 'line; with semicolon', 50245, 'O''Brien', '--not a comment'),
  (59019, DEFAULT, 'O''Brien', 'a b c', 396.85),
  (FALSE, '--not a comment', 62514, 'EUR', 58196),
  ('shipped', 938.93, 'O''Brien', NULL, 49357),
  (292.86, 'line; with semicolon', 'line; with semicolon', 'shipped', 'x@example.com'),
  (44704, 80307, 70531, NULL, 'x@example.com'),
  (61127, 'shipped', now(), 58539, 'EUR'),
  (67000, 241.44, 747.85, 93570, 'O''Brien'),
  ('2026-01-04', 13333, 74.52, '--not a comment', '--not a comment'),
  ('line; with semicolon', NULL, NULL, 'shipped', DEFAULT),
  (98631, DEFAULT, NULL, 878.73, 18418),
  (15544, 'x@example.com', 24131, 62292, 351.10),
  ('--not a comment', 86323, DEFAULT, 'O''Brien', 'x@example.com'),
  (711.87, 'pending', 51591, 'shipped', 'line; with semicolon'),
  (now(), 19630, 18544, NULL, 82510),
  (601.19, NULL, 440.69, 'pending', 82367),
  (959.43, 102.78, 34837, 59841, 89676),
  (97032, 'pending', 'pending', 30226, '2026-01-08'),
  ('x@example.com', '--not a comment', 35858, 23622, 91386),
  ('pending', 'x@example.com', NULL, 'x@example.com', 843.52),
  ('pending', 'x@example.com', 14095, 'pending', 60214),
  (77293, 90495, 'EUR', 79297, 60287),
  (87114, 77811, 58094, 'a b c', 'line; with semicolon'),
  ('2026-01-05', 80213, 54722, 72060, 752.42),
  (65480, 318.16, 328.32, 40313, 'O''Brien'),
  ('EUR', NULL, 19174, 25213, DEFAULT),
  ('x@example.com', 'a b c', 70204, 66233, 739),
  ('x@example.com', '2026-01-04', NULL, 29235, 69817),
  ('a b c', 'O''Brien', 216.05, 79605, FALSE),
  (31458, '2026-01-07', 'a b c', 'line; with semicolon', now()),
  ('pending', 731.65, DEFAULT, '--not a comment', 'line; with semicolon'),
  (75.60, 'x@example.com', '2026-01-08', 83711, NULL),
  (95.84, 76.23, 38359, 'shipped', 'EUR'),
  (945.92, NULL, 'x@example.com', 'pending', 90414),
  (59389, 1897, NULL, 'line; with semicolon', 98343),
  (23586, 12719, 'EUR', '--not a comment', 95598),
  ('O''Brien', 7338, 'x@example.com', DEFAULT, 44949),
  ('a b c', 'shipped', '--not a comment', NULL, NULL),
  (48280, NULL, 24550, 90719, 'a b c'),
  (167.94, 858.96, '2026-01-04', 'pending', 'line; with semicolon'),
  (138.37, 88635, 'O''Brien', 583.17, 'O''Brien'),
  ('EUR', NULL, 586.08, 13721, '--not a comment'),
  (NULL, 'a b c', now(), DEFAULT, 826.58),
  (NULL, 554.96, DEFAULT, 'EUR', 'line; with semicolon'),
  ('EUR', 89745, 'pending', 75780, 69644),
  ('shipped', 760.93, 'line; with semicolon', '2026-01-07', 'x@example.com'),
  (53738, '2026-01-04', 'a b c', '--not a comment', 65057),
  ('O''Brien', 698.43, 'shipped', 'pending', 840.89),
  (NULL, 'shipped', 35408, 182.92, 'shipped'),
  ('--not a comment', '2026-01-05', 702.28, 'pending', 'pending'),
  ('x@example.com', '--not a comment', 59.53, 'O''Brien', NULL),
  ('O''Brien', TRUE, 540.22, 'EUR', DEFAULT),
  (458.43, 'line; with semicolon', 566.04, 41648, 812.25),
  (90.36, 'a b c', 'a b c', '2026-01-06', 774.85),
  ('line; with semicolon', 38102, 516.58, DEFAULT, 'line; with semicolon'),
  (600.39, 'pending', 70603, FALSE, 'a b c'),
  ('shipped', 87155, 'pending', 67152, '2026-01-04'),
  ('EUR', 95094, 4031, '--not a comment', 'EUR'),
  (507.11, NULL, 'line; with semicolon', NULL, 'x@example.com'),
  (NULL, 'shipped', NULL, 'line; with semicolon', now()),
  ('--not a comment', 97569, 'shipped', '--not a comment', NULL),
  ('a b c', now(), 722.42, 'a b c', 'O''Brien'),
  ('2026-01-09', NULL, NULL, 74451, 13.30),
  ('EUR', '--not a comment', 'EUR', 45615, 732.45),
  ('shipped', 37812, 93414, 634.38, 84895),
  (NULL, 906.87, 868.28, 166.25, 799),
  (665.80, 26271, 23172, 'pending', 703.20),
  (97941, 'x@example.com', 612.63, 'O''Brien', '2026-01-05'),
  (FALSE, 18377, 19225, NULL, 'shipped'),
  ('--not a comment', 'a b c', '2026-01-03', 39.64, 'O''Brien'),
  ('line; with semicolon', 253.79, 77730, NULL, 6039),
  ('EUR', 40912, 'x@example.com', 'a b c', 92557),
  ('x@example.com', 'EUR', 366.93, 51559, 'EUR'),
  ('a b c', '2026-01-01', 'O''Brien', 36920, 652.04),
  (TRUE, 'x@example.com', 33.12, 'a b c', 803.65),
  (25027, 45164, 71746, 'x@example.com', 758.28),
  ('O''Brien', 61444, 'x@example.com', '2026-01-03', 77991),
  ('2026-01-06', DEFAULT, 24527, 57896, 'shipped'),
  (NULL, now(), 'x@example.com', NULL, 31865),
  ('pending', '--not a comment', FALSE, NULL, 'O''Brien'),
  (34091, 41780, 1593, 107.91, 60049),
  (36.13, NULL, 'x@example.com', NULL, '2026-01-01'),
  ('shipped', 50581, 'shipped', NULL, 77426),
  ('O''Brien', 'pending', NULL, 93030, 'EUR'),
  ('a b c', 2870, 53192, now(), '2026-01-07'),
  ('shipped', 'a b c', 654.76, 'O''Brien', NULL),
  (74444, 16119, 'O''Brien', 58187, NULL),
  (80774, 59287, 'a b c', 90155, 684.50),
  ('shipped', TRUE, NULL, 'EUR', 36226),
  ('EUR', 333.64, '--not a comment', 93270, NULL),
  (51.78, 'EUR', now(), 652.21, now()),
  (NULL, 246.03, 58727, NULL, 32498),
  ('pending', '--not a comment', TRUE, 'a b c', '2026-01-03'),
  (TRUE, 66449, 'shipped', 'x@example.com', 783.77),
  ('--not a comment', 83356, DEFAULT, DEFAULT, 74664),
  ('EUR', DEFAULT, NULL, NULL, 'pending'),
  (NULL, '2026-01-01', 'x@example.com', 'x@example.com', 96262),
  ('x@example.com', 79.46, 70685, NULL, 'a b c'),
  (82592, 'x@example.com', TRUE, 'EUR', 'pending'),
  ('--not a comment', NULL, '--not a comment', FALSE, DEFAULT),
  (71610, 567.74, TRUE, NULL, 'line; with semicolon'),
  (56939, 'a b c', 572.70, 788.10, 79704),
  (NULL, 273.86, 'x@example.com', 'line; with semicolon', 48202),
  (NULL, 'line; with semicolon', 61871, 88765, 'a b c'),
  (68116, NULL, now(), FALSE, 'O''Brien'),
  (3558, 146.97, 154.22, NULL, 562.50),
  (NULL, '2026-01-08', 268.05, 'a b c', 92665),
  (98325, 'EUR', 'x@example.com', NULL, 'EUR'),
  ('pending', 51804, 222, 'line; with semicolon', 'shipped'),
  (88767, 619.43, 19675, 'O''Brien', NULL),
  (TRUE, NULL, 46351, 'a b c', 'EUR'),
  (19910, 93365, TRUE, 'line; with semicolon', 'a b c'),
  (NULL, DEFAULT, 7903, 'O''Brien', 58357),
  ('EUR', 79776, 290.09, 'EUR', FALSE),
  ('EUR', '--not a comment', 'a b c', 32578, 'O''Brien'),
  ('O''Brien', 38596, 'pending', DEFAULT, 'EUR'),
  ('--not a comment', 'a b c', 410.02, 'O''Brien', NULL),
  (914.79, 'pending', TRUE, DEFAULT, 356.65),
  ('2026-01-03', 365.11, 409.21, NULL, 'shipped'),
  (34146, 2562, 7837, 98366, 690.59),
  (44223, 717.20, 76208, '--not a comment', 51807),
  (33041, 'O''Brien', NULL, 'line; with semicolon', 54794),
  (NULL, 44093, DEFAULT, 71768, 82844),
  (34966, '--not a comment', 'x@example.com', 'O''Brien', TRUE),
  (28037, 'x@example.com', 'O''Brien', NULL, '2026-01-02'),
  ('2026-01-06', 587.49, 116.98, 68311, 74635),
  ('x@example.com', 'O''Brien', DEFAULT, 905.97, 'EUR'),
  (22186, 'shipped', 29776, 16759, '--not a comment'),
  (13699, 86581, 'pending', 'shipped', 'line; with semicolon'),
  ('a b c', TRUE, 'pending', 788.32, 184.16),
  ('line; with semicolon', 'EUR', 'x@example.com', 88164, 1892),
  (73584, NULL, '2026-01-05', FALSE, NULL),
  (14129, NULL, 55346, 16198, 48821),
  (NULL, 'EUR', NULL, 'line; with semicolon', 'x@example.com'),
  (21476, FALSE, 68189, FALSE, 12338),
  (29688, 'a b c', TRUE, 99363, NULL),
  ('line; with semicolon', 'EUR', '2026-01-08', 12237, NULL),
  ('line; with semicolon', 13408, 'O''Brien', 96537, DEFAULT),
  ('2026-01-07', '--not a comment', 37652, 99560, 'x@example.com'),
  (NULL, 'line; with semicolon', 312, 'a b c', NULL),
  (NULL, TRUE, 25561, now(), 969.18),
  ('EUR', 'shipped', 31858, 'x@example.com', 'a b c'),
  ('2026-01-05', 74947, NULL, 42.49, 'pending'),
  ('x@example.com', 'pending', 'shipped', '--not a comment', NULL),
  ('EUR', 'line; with semicolon', NULL, 32098, DEFAULT),
  ('line; with semicolon', 78609, NULL, 32881, NULL),
  (NULL, 82989, 'EUR', 'pending', 48262),
  ('shipped', NULL, '--not a comment', 658.51, FALSE),
  ('x@example.com', 83976, 'a b c', 85286, '2026-01-01'),
  (58226, 'line; with semicolon', NULL, 'a b c', 5521),
  (NULL, 'pending', 49040, FALSE, 'line; with semicolon'),
  (11137, NULL, 965.45, '--not a comment', NULL),
  ('EUR', 'EUR', 32494, 413.85, 66149),
  (32344, 953.20, 22408, 516.53, 66352),
  ('line; with semicolon', '--not a comment', 6766, 56350, 'O''Brien'),
  (7174, 20.85, 38709, 90267, 88959),
  ('a b c', 99.60, 27196, 345.80, TRUE),
  (92938, 45973, now(), 'x@example.com', 81006),
  (141.69, 243.77, 87904, 'O''Brien', 76925),
  (75760, 22.67, 66834, '2026-01-04', 'line; with semicolon'),
  (26357, 375.18, 'pending', 'x@example.com', NULL),
  (561.96, NULL, NULL, 'pending', 693.01),
  ('2026-01-03', 609.53, 75822, 'line; with semicolon', 'x@example.com'),
  ('line; with semicolon', 'O''Brien', 'EUR', NULL, 80264),
  (70222, NULL, 'pending', 807.41, 6115),
  (6503, 26027, 1883, 'EUR', 60553),
  ('--not a comment', 43535, now(), NULL, '--not a comment'),
  ('x@example.com', '2026-01-01', 96058, '--not a comment', FALSE),
  (31418, 'pending', 54639, 'shipped', 89885),
  (NULL, 97173, 'a b c', NULL, 'x@example.com'),
  ('shipped', 'shipped', 'shipped', 1489, 835.35),
  (11794, NULL, 'a b c', 678.85, 'pending'),
  (789.61, 'a b c', 62569, 3463, 'O''Brien'),
  (676.28, 206.40, 36919, 521.44, 38718),
  (453.22, 581.17, 80943, 96973, 71856),
  ('EUR', NULL, 74323, 54842, '--not a comment'),
  (91220, 'O''Brien', 'line; with semicolon', 'a b c', 'O''Brien'),
  (20814, FALSE, now(), 'shipped', 67364),
  ('x@example.com', NULL, TRUE, NULL, 830.12),
  ('line; with semicolon', 7351, NULL, 'x@example.com', 'pending'),
  (99224, 'x@example.com', 'EUR', 68395, FALSE),
  ('O''Brien', 456.28, 'shipped', 259.04, NULL),
  (NULL, 13164, DEFAULT, FALSE, TRUE),
  ('pending', 'shipped', 93344, 19516, 'O''Brien'),
  ('a b c', 50048, NULL, '2026-01-08', 'EUR'),
  ('EUR', 'x@example.com', NULL, 10961, now()),
  (680.59, TRUE, NULL, 'x@example.com', 'x@example.com'),
  (79104, NULL, 53574, '--not a comment', 243.04),
  (TRUE, 238.72, 31479, 97209, TRUE),
  (NULL, 'EUR', 59635, 'shipped', 105.97),
  (DEFAULT, 646.19, 'x@example.com', 679.20, NULL),
  ('line; with semicolon', 68803, 'EUR', '--not a comment', 'shipped'),
  (96541, 77.12, now(), 97879, NULL),
  (now(), NULL, 87655, 42190, 'EUR'),
  (46735, 24666, DEFAULT, 866.98, 29528),
  (29544, 68897, 64128, 503.23, FALSE),
  ('2026-01-06', FALSE, TRUE, '--not a comment', now()),
  ('EUR', 79250, 15437, 'line; with semicolon', NULL),
  (74088, NULL, 36087, 62642, 'pending'),
  ('pending', 89961, FALSE, 25571, 'pending'),
  (278.88, '--not a comment', '--not a comment', 229.83, 'pending'),
  (47737, 'EUR', FALSE, 82782, 75412),
  ('a b c', 499.73, 491.70, 10902, 26411),
  (992.46, now(), 374.89, NULL, 49598),
  (86134, 'EUR', NULL, 'a b c', 48991),
  (48379, 'pending', 69310, 50779, 1937),
  (561.68, 516.35, 80644, 32451, 521.62),
  ('x@example.com', 54116, 'EUR', 'pending', 41634),
  (now(), 44232, TRUE, NULL, 90649),
  (59224, DEFAULT, TRUE, 49097, 19560),
  ('pending', 79469, '2026-01-08', 'O''Brien', 21848),
  (NULL, 14491, 870.43, 884.73, 91429),
  ('--not a comment', 56639, 'a b c', NULL, 38973),
  ('line; with semicolon', 'EUR', TRUE, NULL, 82244);

-- touch categories
SELECT count(*) FROM categories WHERE currency BETWEEN 33 AND 63;
DELETE FROM users WHERE product_id < 39011 OR order_id IN (48, 85, 22);
UPDATE inventory SET updated_at = 84501, price = city + 1 WHERE country = 5785 AND currency IS NOT NULL;
UPDATE products SET product_id = 362.87, updated_at = product_id + 1 WHERE product_id = 2369 AND note IS NOT NULL;
INSERT INTO carriers (email, country, id, order_id) VALUES (48684, DEFAULT, NULL, 'pending');
UPDATE invoices SET sku = 7973, created_at = city + 1 WHERE qty = 6503 AND amount IS NOT NULL;
UPDATE reviews SET id = 'line; with semicolon', updated_at = country + 1 WHERE discount = 5312 AND email IS NOT NULL;
INSERT INTO products (total, country, email, order_id) VALUES ('pending', 33269, 'EUR', '--not a comment');
DELETE FROM warehouses WHERE name < 'line; with semicolon' OR user_id IN (42, 96, 91);
INSERT INTO warehouses (created_at, sku, id, note) VALUES (423.02, NULL, 'line; with semicolon', 'line; with semicolon');
INSERT INTO carriers (sku, currency, discount, note) VALUES (now(), 'a b c', 19099, 64.42);
-- touch events
SELECT count(*) FROM events WHERE id BETWEEN 21 AND 89;
UPDATE inventory SET updated_at = 77643, price = order_id + 1 WHERE order_id = 6782 AND note IS NOT NULL;
INSERT INTO coupons (product_id, total, sku, currency) VALUES ('pending', 73004, 'shipped', 16526);
INSERT INTO payments (order_id, product_id, qty, currency) VALUES (TRUE, 'EUR', 'pending', 'pending');
INSERT INTO invoices (order_id, city, currency, sku) VALUES (20688, 'shipped', 'pending', 22144);
UPDATE shipments SET city = 'O''Brien', created_at = sku + 1 WHERE product_id = 7168 AND city IS NOT NULL;
-- touch coupons
SELECT count(*) FROM coupons WHERE note BETWEEN 49 AND 52;
UPDATE users SET city = 40974, kind = qty + 1 WHERE created_at = 1333 AND name IS NOT NULL;
INSERT INTO users (currency, country, created_at, product_id) VALUES ('a b c', 177.61, 'O''Brien', 25454);
UPDATE products SET kind = 284.76, total = currency + 1 WHERE discount = 864 AND product_id IS NOT NULL;
UPDATE refunds SET user_id = 3.53, country = kind + 1 WHERE price = 1361 AND city IS NOT NULL;
INSERT INTO invoices (id, discount, product_id, city) VALUES (943.94, NULL, 'a b c', 84794);
UPDATE products SET total = 528.68, email = discount + 1 WHERE total = 2111 AND note IS NOT NULL;
UPDATE reviews SET id = 'O''Brien', user_id = order_id + 1 WHERE note = 6026 AND amount IS NOT NULL;
UPDATE sessions SET user_id = '--not a comment', currency = total + 1 WHERE note = 7693 AND price IS NOT NULL;
INSERT INTO audit_log (amount, qty, country, status) VALUES (23964, 'line; with semicolon', 'line; with semicolon', '--not a comment');
UPDATE subscriptions SET name = 265.94, created_at = currency + 1 WHERE created_at = 9966 AND order_id IS NOT NULL;
UPDATE refunds SET discount = NULL, sku = status + 1 WHERE email = 6465 AND price IS NOT NULL;
INSERT INTO coupons (created_at, sku, status, city) VALUES (350.92, 'x@example.com', 'O''Brien', 126.46);
DELETE FROM users WHERE country < 53252 OR note IN (72, 76, 7, 26);
UPDATE carriers SET user_id = 'a b c', updated_at = id + 1 WHERE total = 2562 AND product_id IS NOT NULL;
UPDATE products SET id = 942.07, qty = user_id + 1 WHERE price = 208 AND amount IS NOT NULL;
UPDATE categories SET product_id = DEFAULT, updated_at = city + 1 WHERE price = 2315 AND note IS NOT NULL;
DELETE FROM warehouses WHERE id < 49197 OR discount IN (16, 80, 25, 5, 92, 88, 1, 48);
INSERT INTO shipments (discount, status, updated_at, email) VALUES ('--not a comment', now(), FALSE, 29381);
DELETE FROM suppliers WHERE order_id < 226 OR qty IN (1, 29, 58, 58, 35, 89, 28);
UPDATE categories SET order_id = 703.19, id = note + 1 WHERE created_at = 5967 AND total IS NOT NULL;
UPDATE suppliers SET currency = NULL, discount = status + 1 WHERE email = 2898 AND status IS NOT NULL;
INSERT INTO carriers (status, sku, email, discount) VALUES (9931, now(), '2026-01-07', 'shipped');
UPDATE suppliers SET user_id = TRUE, price = created_at + 1 WHERE price = 2495 AND total IS NOT NULL;
-- touch suppliers
SELECT count(*) FROM suppliers WHERE qty BETWEEN 16 AND 99;
INSERT INTO categories (id, city, country, email) VALUES (TRUE, 991.44, 85638, 13325);
INSERT INTO invoices (updated_at, total, product_id, country) VALUES (51830, 'shipped', 25583, 'O''Brien');
DELETE FROM products WHERE country < DEFAULT OR updated_at IN (61, 4, 44, 45);
INSERT INTO sessions (product_id, user_id, updated_at, qty) VALUES (64790, TRUE, NULL, 75.86);
UPDATE products SET product_id = 17676, city = qty + 1 WHERE user_id = 654 AND kind IS NOT NULL;
DELETE FROM inventory WHERE created_at < 74189 OR city IN (72, 51, 82, 82, 4, 41);
UPDATE warehouses SET kind = 'shipped', id = order_id + 1 WHERE city = 5468 AND status IS NOT NULL;
DELETE FROM payments WHERE email < 85425 OR id IN (33, 85, 51, 23);
INSERT INTO events (currency, user_id, kind, country) VALUES ('a b c', 563, 'x@example.com', 781.71);
DELETE FROM shipments WHERE created_at < 'shipped' OR created_at IN (78, 70, 64, 1, 57, 14, 8);
UPDATE subscriptions SET name = NULL, currency = qty + 1 WHERE status = 3268 AND city IS NOT NULL;
INSERT INTO events (city, sku, discount, email) VALUES ('EUR', 'pending', 49313, 'O''Brien');
UPDATE inventory SET name = 99963, order_id = id + 1 WHERE product_id = 5344 AND city IS NOT NULL;
DELETE FROM categories WHERE currency < 'line; with semicolon' OR note IN (67, 66, 48, 29, 95, 96);
INSERT INTO invoices (note, name, kind, city) VALUES (FALSE, 72111, 'shipped', 45890);
INSERT INTO order_items (total, product_id, sku, updated_at) VALUES ('O''Brien', NULL, NULL, 5884);
UPDATE invoices SET sku = '2026-01-07', total = email + 1 WHERE amount = 7129 AND order_id IS NOT NULL;
INSERT INTO orders (id, created_at, updated_at, product_id) VALUES ('O''Brien', 'shipped', 'shipped', 44409);
INSERT INTO subscriptions (name, updated_at, discount, kind) VALUES (35545, 188.67, 'EUR', 24.20);
INSERT INTO sessions (note, amount, currency, discount) VALUES (93269, 'a b c', 62093, '2026-01-04');
INSERT INTO orders (price, kind, note, total) VALUES (216.77, 51854, DEFAULT, 'O''Brien');
-- touch shipments
SELECT count(*) FROM shipments WHERE note BETWEEN 46 AND 74;
-- touch events
SELECT count(*) FROM events WHERE updated_at BETWEEN 44 AND 75;
UPDATE suppliers SET sku = 'a b c', email = sku + 1 WHERE id = 4003 AND discount IS NOT NULL;
INSERT INTO warehouses (currency, total, sku, price) VALUES (NULL, 36633, 68359, 20492);
DELETE FROM invoices WHERE currency < 65982 OR order_id IN (12, 90, 6);
UPDATE events SET currency = now(), city = total + 1 WHERE note = 6471 AND product_id IS NOT NULL;
UPDATE orders SET price = 74046, qty = price + 1 WHERE status = 6246 AND name IS NOT NULL;
INSERT INTO audit_log (name, sku, price, city) VALUES (47962, 'x@example.com', TRUE, DEFAULT);
INSERT INTO sessions (qty, updated_at, sku, country) VALUES (now(), 4472, 'EUR', 792);
DELETE FROM order_items WHERE amount < NULL OR updated_at IN (3, 14, 14, 49, 40);
INSERT INTO coupons (note, country, amount, qty) VALUES (NULL, 'O''Brien', '--not a comment', DEFAULT);
INSERT INTO warehouses (price, updated_at, id, total) VALUES ('a b c', 9875, 'x@example.com', 98355);
INSERT INTO categories (id, discount, total, qty) VALUES ('pending', 'a b c', DEFAULT, 5332);
INSERT INTO subscriptions (product_id, price, qty, name) VALUES (8259, 'a b c', 'EUR', 75441);
-- touch order_items
SELECT count(*) FROM order_items WHERE kind BETWEEN 24 AND 87;
INSERT INTO audit_log (currency, status, price, total) VALUES ('2026-01-08', 'x@example.com', 76130, 'x@example.com');
UPDATE events SET name = 'x@example.com', country = name + 1 WHERE id = 2516 AND product_id IS NOT NULL;
DELETE FROM orders WHERE note < now() OR country IN (52, 86, 42);
UPDATE users SET amount = 32043, status = qty + 1 WHERE price = 389 AND updated_at IS NOT NULL;
UPDATE refunds SET status = 62877, city = price + 1 WHERE country = 8173 AND discount IS NOT NULL;
-- touch warehouses
SELECT count(*) FROM warehouses WHERE id BETWEEN 28 AND 83;
INSERT INTO products (name, user_id, id, city) VALUES ('a b c', '2026-01-05', '--not a comment', 'pending');
DELETE FROM categories WHERE currency < 'shipped' OR discount IN (89, 98);
INSERT INTO carriers (country, total, price, id) VALUES (176.31, '2026-01-03', 'line; with semicolon', TRUE);
INSERT INTO reviews (kind, amount, user_id, product_id) VALUES ('2026-01-02', 'EUR', 'shipped', 'line; with semicolon');
INSERT INTO categories (status, kind, order_id, user_id) VALUES (44400, 10469, 24549, 17885);
INSERT INTO warehouses (amount, discount, country, qty) VALUES ('--not a comment', 63108, 'a b c', '2026-01-05');
DELETE FROM events WHERE discount < NULL OR order_id IN (87, 73, 24, 19, 76, 70, 7);
INSERT INTO carriers (currency, status, qty, name) VALUES (41244, 93764, 'x@example.com', 671.34);
-- touch orders
SELECT count(*) FROM orders WHERE name BETWEEN 24 AND 92;
INSERT INTO sessions (updated_at, kind, email, product_id) VALUES (31512, 833.82, NULL, 52036);
INSERT INTO invoices (created_at, currency, qty, email) VALUES (8.11, FALSE, '2026-01-02', 860.93);
UPDATE users SET city = 'shipped', id = product_id + 1 WHERE price = 2631 AND currency IS NOT NULL;
UPDATE coupons SET discount = '--not a comment', total = amount + 1 WHERE note = 8829 AND user_id IS NOT NULL;
INSERT INTO invoices (email, status, note, id) VALUES (315.81, 715.58, 23942, 69205);
-- touch addresses
SELECT count(*) FROM addresses WHERE created_at BETWEEN 38 AND 61;
UPDATE audit_log SET user_id = 38531, qty = id + 1 WHERE qty = 3343 AND kind IS NOT NULL;
UPDATE coupons SET price = NULL, created_at = country + 1 WHERE updated_at = 997 AND name IS NOT NULL;
DELETE FROM warehouses WHERE user_id < 364.29 OR note IN (27, 82, 78, 18, 54, 38, 35);
UPDATE users SET user_id = 66680, currency = amount + 1 WHERE user_id = 5628 AND city IS NOT NULL;
-- touch events
SELECT count(*) FROM events WHERE total BETWEEN 16 AND 72;
UPDATE shipments SET currency = 947.13, sku = order_id + 1 WHERE order_id = 5840 AND user_id IS NOT NULL;
INSERT INTO events (price, id, product_id, currency) VALUES (54140, 902.97, 58944, NULL);
INSERT INTO orders (product_id, note, country, status) VALUES (864.90, 'EUR', 'x@example.com', 64084);
DELETE FROM inventory WHERE updated_at < 98479 OR user_id IN (51, 18, 75, 48, 64, 65);
INSERT INTO carriers (updated_at, total, qty, city) VALUES (391.09, '--not a comment', DEFAULT, 109.76);
INSERT INTO inventory (total, status, country, product_id) VALUES (1.60, TRUE, NULL, 'pending');
INSERT INTO sessions (created_at, user_id, product_id, price) VALUES (287.81, '--not a comment', 'pending', 'EUR');
INSERT INTO users (created_at, user_id, sku, city) VALUES ('shipped', TRUE, TRUE, NULL);
INSERT INTO orders (currency, order_id, amount, country) VALUES ('x@example.com', NULL, 'EUR', 'a b c');
UPDATE audit_log SET sku = 618, kind = discount + 1 WHERE email = 6973 AND note IS NOT NULL;
DELETE FROM shipments WHERE product_id < 13011 OR status IN (45, 62, 23, 47, 82, 7, 10);
UPDATE suppliers SET city = 99715, qty = discount + 1 WHERE kind = 7122 AND user_id IS NOT NULL;
INSERT INTO carriers (sku, currency, user_id, city) VALUES ('EUR', 'shipped', 47908, 3000);
DELETE FROM coupons WHERE city < NULL OR email IN (88, 15);
-- touch inventory
SELECT count(*) FROM inventory WHERE order_id BETWEEN 24 AND 88;
UPDATE categories SET qty = NULL, kind = currency + 1 WHERE updated_at = 7997 AND created_at IS NOT NULL;
DELETE FROM orders WHERE status < 242.50 OR updated_at IN (14, 20);
UPDATE orders SET sku = 21089, created_at = total + 1 WHERE total = 8068 AND id IS NOT NULL;
UPDATE reviews SET updated_at = 'O''Brien', order_id = status + 1 WHERE created_at = 9976 AND total IS NOT NULL;
INSERT INTO products (sku, qty, updated_at, user_id) VALUES ('line; with semicolon', 4399, 81189, TRUE);
INSERT INTO events (product_id, qty, updated_at, country) VALUES (49098, 50593, 10256, 92382);
UPDATE sessions SET product_id = 12090, created_at = country + 1 WHERE price = 1505 AND kind IS NOT NULL;
INSERT INTO shipments (kind, city, id, note) VALUES (NULL, 973.48, 'pending', 51211);
-- touch warehouses
SELECT count(*) FROM warehouses WHERE user_id BETWEEN 18 AND 85;
INSERT INTO order_items (created_at, status, currency, city) VALUES (40411, 300.86, '2026-01-08', 'a b c');
UPDATE categories SET status = 87804, product_id = order_id + 1 WHERE price = 5824 AND updated_at IS NOT NULL;
INSERT INTO suppliers (country, email, kind, sku) VALUES (25824, '2026-01-02', TRUE, NULL);
-- touch payments
SELECT count(*) FROM payments WHERE email BETWEEN 10 AND 56;
UPDATE inventory SET amount = 32187, status = country + 1 WHERE total = 215 AND city IS NOT NULL;
DELETE FROM warehouses WHERE amount < DEFAULT OR price IN (62, 72, 88, 28, 45);
INSERT INTO suppliers (total, updated_at, note, status) VALUES ('a b c', 34588, '--not a comment', 99413);
INSERT INTO subscriptions (order_id, kind, price, id) VALUES (135.37, 'shipped', TRUE, '--not a comment');
INSERT INTO events (email, currency, order_id, kind) VALUES (69932, 80023, NULL, NULL);
INSERT INTO refunds (updated_at, id, discount, status) VALUES ('O''Brien', 'a b c', 'shipped', 560.77);
INSERT INTO coupons (country, created_at, total, email) VALUES ('--not a comment', DEFAULT, 'x@example.com', NULL);
UPDATE order_items SET updated_at = NULL, kind = sku + 1 WHERE currency = 7066 AND country IS NOT NULL;
UPDATE invoices SET price = 'a b c', product_id = price + 1 WHERE sku = 1695 AND product_id IS NOT NULL;
UPDATE orders SET price = 61840, discount = user_id + 1 WHERE city = 3261 AND product_id IS NOT NULL;
UPDATE orders SET discount = 'O''Brien', discount = qty + 1 WHERE status = 7166 AND qty IS NOT NULL;
INSERT INTO subscriptions (email, kind, qty, currency) VALUES ('x@example.com', NULL, 69675, 157.02);
INSERT INTO addresses (status, order_id, kind, created_at) VALUES (FALSE, NULL, 28074, 'a b c');
UPDATE refunds SET kind = 43553, country = sku + 1 WHERE name = 4205 AND kind IS NOT NULL;
UPDATE categories SET currency = now(), order_id = updated_at + 1 WHERE updated_at = 2679 AND qty IS NOT NULL;
UPDATE shipments SET sku = 'line; with semicolon', product_id = currency + 1 WHERE currency = 4678 AND sku IS NOT NULL;
INSERT INTO reviews (qty, kind, user_id, id) VALUES (NULL, 'line; with semicolon', '2026-01-09', 626.80);
INSERT INTO sessions (city, user_id, total, order_id) VALUES ('EUR', NULL, 552.78, NULL);
DELETE FROM coupons WHERE status < FALSE OR amount IN (92, 57);
UPDATE subscriptions SET price = 'O''Brien', amount = city + 1 WHERE name = 9559 AND product_id IS NOT NULL;
DELETE FROM suppliers WHERE kind < 'a b c' OR note IN (71, 53, 6, 20, 18, 24);
UPDATE refunds SET country = 'x@example.com', city = kind + 1 WHERE total = 5976 AND email IS NOT NULL;
INSERT INTO coupons (order_id, name, created_at, city) VALUES (331.05, NULL, 59268, TRUE);
UPDATE categories SET order_id = 55.91, product_id = city + 1 WHERE kind = 6036 AND qty IS NOT NULL;
INSERT INTO payments (email, city, created_at, sku) VALUES (80298, NULL, 310.16, 'line; with semicolon');
UPDATE invoices SET created_at = TRUE, id = currency + 1 WHERE user_id = 7977 AND amount IS NOT NULL;
UPDATE subscriptions SET created_at = 169.68, updated_at = note + 1 WHERE updated_at = 7429 AND status IS NOT NULL;
UPDATE coupons SET currency = NULL, kind = order_id + 1 WHERE created_at = 3688 AND city IS NOT NULL;
INSERT INTO addresses (created_at, kind, currency, note) VALUES ('x@example.com', NULL, 'x@example.com', 253.93);
DELETE FROM refunds WHERE id < 'pending' OR country IN (1, 60, 47, 60, 97);
-- touch suppliers
SELECT count(*) FROM suppliers WHERE qty BETWEEN 43 AND 56;
-- touch users
SELECT count(*) FROM users WHERE product_id BETWEEN 4 AND 68;
INSERT INTO carriers (product_id, sku, note, qty) VALUES (12891, 'EUR', NULL, 51154);
UPDATE products SET discount = 10276, product_id = product_id + 1 WHERE qty = 8085 AND id IS NOT NULL;
UPDATE payments SET user_id = 'EUR', name = total + 1 WHERE discount = 2862 AND name IS NOT NULL;
INSERT INTO order_items (currency, discount, created_at, price) VALUES (NULL, 'pending', 60914, '2026-01-02');
INSERT INTO products (email, currency, amount, order_id) VALUES ('line; with semicolon', DEFAULT, 66178, 'shipped');
UPDATE audit_log SET price = 208.17, city = product_id + 1 WHERE email = 4880 AND amount IS NOT NULL;
-- touch carriers
SELECT count(*) FROM carriers WHERE status BETWEEN 46 AND 65;
UPDATE refunds SET order_id = 87273, email = price + 1 WHERE amount = 9051 AND note IS NOT NULL;
UPDATE categories SET total = 'a b c', qty = email + 1 WHERE currency = 8349 AND city IS NOT NULL;
INSERT INTO refunds (status, id, discount, city) VALUES ('shipped', DEFAULT, 60769, 'line; with semicolon');
DELETE FROM users WHERE price < NULL OR user_id IN (11, 36, 48);
INSERT INTO orders (email, product_id, total, order_id) VALUES ('shipped', 87983, 'shipped', 83854);
INSERT INTO coupons (email, amount, created_at, total) VALUES (42474, '--not a comment', 'pending', 'x@example.com');
-- touch refunds
SELECT count(*) FROM refunds WHERE email BETWEEN 8 AND 57;
UPDATE carriers SET order_id = 241.72, created_at = note + 1 WHERE price = 1949 AND discount IS NOT NULL;
INSERT INTO reviews (sku, product_id, discount, email) VALUES ('line; with semicolon', NULL, DEFAULT, 676.06);
UPDATE events SET user_id = now(), user_id = email + 1 WHERE status = 8641 AND currency IS NOT NULL;
INSERT INTO shipments (note, kind, currency, user_id) VALUES ('a b c', '2026-01-01', TRUE, 'x@example.com');
DELETE FROM suppliers WHERE created_at < 'line; with semicolon' OR note IN (70, 36, 69, 41, 32, 7);
-- touch products
SELECT count(*) FROM products WHERE order_id BETWEEN 32 AND 99;
INSERT INTO products (kind, order_id, currency, name) VALUES (33139, 'pending', 'x@example.com', 69296);
INSERT INTO warehouses (created_at, amount, country, price) VALUES (690.78, 777.71, 11151, 53610);
UPDATE invoices SET status = 54184, updated_at = city + 1 WHERE name = 9895 AND amount IS NOT NULL;
UPDATE sessions SET product_id = 'a b c', discount = total + 1 WHERE id = 6966 AND qty IS NOT NULL;
UPDATE coupons SET price = 43291, sku = country + 1 WHERE note = 9125 AND total IS NOT NULL;
UPDATE coupons SET kind = 70197, price = created_at + 1 WHERE sku = 3468 AND product_id IS NOT NULL;
INSERT INTO categories (discount, note, name, country) VALUES ('x@example.com', 'x@example.com', 89154, '--not a comment');
DELETE FROM coupons WHERE status < 'EUR' OR updated_at IN (98, 6, 17, 51, 71);
INSERT INTO events (country, id, note, price) VALUES ('pending', 21.54, 58333, 'EUR');
UPDATE audit_log SET product_id = '--not a comment', discount = amount + 1 WHERE product_id = 6944 AND qty IS NOT NULL;
UPDATE sessions SET user_id = '2026-01-07', sku = sku + 1 WHERE user_id = 1122 AND name IS NOT NULL;
UPDATE shipments SET email = 88933, order_id = note + 1 WHERE country = 1567 AND product_id IS NOT NULL;
INSERT INTO audit_log (kind, qty, product_id, amount) VALUES (NULL, 'line; with semicolon', 62121, 'line; with semicolon');
INSERT INTO refunds (note, email, amount, country) VALUES (82945, 'shipped', '2026-01-07', 68517);
INSERT INTO warehouses (amount, email, qty, user_id) VALUES (NULL, 'pending', NULL, NULL);
INSERT INTO subscriptions (amount, status, price, created_at) VALUES (52225, DEFAULT, 'O''Brien', 28259);
INSERT INTO sessions (product_id, currency, discount, amount) VALUES (FALSE, 'pending', 946.16, 'EUR');
INSERT INTO products (sku, order_id, total, user_id) VALUES (NULL, TRUE, NULL, now());
INSERT INTO payments (sku, id, price, note) VALUES (68870, 'EUR', NULL, 'a b c');
UPDATE coupons SET id = now(), currency = user_id + 1 WHERE kind = 3759 AND note IS NOT NULL;
-- touch orders
SELECT count(*) FROM orders WHERE id BETWEEN 44 AND 56;
-- touch users
SELECT count(*) FROM users WHERE updated_at BETWEEN 38 AND 96;
-- touch payments
SELECT count(*) FROM payments WHERE currency BETWEEN 25 AND 70;
UPDATE users SET total = now(), updated_at = email + 1 WHERE price = 7785 AND qty IS NOT NULL;
UPDATE warehouses SET city = NULL, order_id = note + 1 WHERE product_id = 7290 AND kind IS NOT NULL;
UPDATE events SET note = 'pending', kind = kind + 1 WHERE currency = 1604 AND status IS NOT NULL;
UPDATE events SET user_id = 84671, id = price + 1 WHERE amount = 9109 AND updated_at IS NOT NULL;
INSERT INTO shipments (amount, order_id, note, country) VALUES ('2026-01-07', NULL, 'shipped', 19494);
INSERT INTO shipments (qty, sku, price, order_id) VALUES (6225, 60984, 'O''Brien', NULL);
DELETE FROM events WHERE user_id < 940.84 OR note IN (4, 5, 66, 98, 6);
UPDATE subscriptions SET created_at = NULL, email = kind + 1 WHERE email = 3553 AND total IS NOT NULL;
-- touch refunds
SELECT count(*) FROM refunds WHERE total BETWEEN 12 AND 56;
UPDATE products SET status = 27822, price = currency + 1 WHERE total = 166 AND country IS NOT NULL;
UPDATE products SET status = 28514, amount = sku + 1 WHERE currency = 3230 AND kind IS NOT NULL;
INSERT INTO carriers (updated_at, currency, kind, status) VALUES ('a b c', 'EUR', 84297, NULL);
INSERT INTO payments (status, sku, currency, qty) VALUES (25624, TRUE, 375.92, NULL);
-- touch shipments
SELECT count(*) FROM shipments WHERE total BETWEEN 32 AND 90;
UPDATE coupons SET kind = 'line; with semicolon', updated_at = email + 1 WHERE price = 1561 AND name IS NOT NULL;
-- touch audit_log
SELECT count(*) FROM audit_log WHERE city BETWEEN 20 AND 86;
UPDATE audit_log SET discount = 'line; with semicolon', total = note + 1 WHERE user_id = 4077 AND user_id IS NOT NULL;
INSERT INTO shipments (order_id, user_id, currency, email) VALUES (74428, 439.25, 49008, FALSE);
UPDATE sessions SET sku = 439.61, amount = sku + 1 WHERE product_id = 4109 AND total IS NOT NULL;
INSERT INTO shipments (status, city, note, created_at) VALUES (23379, 90.94, '2026-01-05', 'a b c');
UPDATE payments SET qty = 'a b c', note = city + 1 WHERE discount = 8003 AND status IS NOT NULL;
UPDATE coupons SET created_at = 'line; with semicolon', qty = product_id + 1 WHERE status = 6510 AND user_id IS NOT NULL;
DELETE FROM events WHERE order_id < 912.81 OR country IN (55, 62, 47, 30, 3, 95);
INSERT INTO suppliers (note, name, id, total) VALUES ('x@example.com', NULL, 38994, 'EUR');
INSERT INTO reviews (city, note, status, amount) VALUES (86058, 'a b c', 55017, 'line; with semicolon');
INSERT INTO products (created_at, name, country, qty) VALUES (15945, 'x@example.com', NULL, now());
UPDATE subscriptions SET product_id = 97536, amount = user_id + 1 WHERE id = 9745 AND email IS NOT NULL;
INSERT INTO suppliers (sku, country, amount, product_id) VALUES (98229, '2026-01-04', 'EUR', 350.49);
INSERT INTO order_items (product_id, status, email, updated_at) VALUES (86857, 677.64, 751.71, 11863);
DELETE FROM categories WHERE qty < 54735 OR city IN (51, 79, 64, 15, 9, 66, 37, 1);
UPDATE suppliers SET price = 62065, user_id = user_id + 1 WHERE currency = 5319 AND qty IS NOT NULL;
INSERT INTO products (user_id, currency, discount, created_at) VALUES ('shipped', 80349, 57659, DEFAULT);
UPDATE order_items SET updated_at = NULL, note = total + 1 WHERE status = 7471 AND order_id IS NOT NULL;
DELETE FROM inventory WHERE kind < 'O''Brien' OR sku IN (96, 46, 10, 24, 41, 66, 74);
UPDATE suppliers SET discount = 'a b c', sku = discount + 1 WHERE price = 4445 AND id IS NOT NULL;
UPDATE users SET id = NULL, total = total + 1 WHERE currency = 3891 AND price IS NOT NULL;
UPDATE carriers SET discount = 80702, kind = total + 1 WHERE country = 3334 AND currency IS NOT NULL;
INSERT INTO orders (city, created_at, amount, name) VALUES (84464, 'line; with semicolon', 471.80, 963.78);
INSERT INTO coupons (city, order_id, updated_at, price) VALUES ('EUR', 37442, 82663, 'line; with semicolon');
INSERT INTO carriers (discount, note, price, kind) VALUES (144.27, 54.89, 402.55, NULL);
DELETE FROM products WHERE price < 'shipped' OR discount IN (46, 71, 69);
UPDATE sessions SET total = 66784, total = kind + 1 WHERE id = 3167 AND name IS NOT NULL;
-- touch addresses
SELECT count(*) FROM addresses WHERE email BETWEEN 12 AND 60;
INSERT INTO orders (total, name, user_id, price) VALUES ('shipped', 'pending', 'x@example.com', NULL);
-- touch subscriptions
SELECT count(*) FROM subscriptions WHERE product_id BETWEEN 11 AND 81;
INSERT INTO sessions (created_at, country, user_id, discount) VALUES (1543, NULL, 94177, '--not a comment');
UPDATE subscriptions SET price = 68325, status = user_id + 1 WHERE discount = 9087 AND name IS NOT NULL;
-- touch carriers
SELECT count(*) FROM carriers WHERE updated_at BETWEEN 23 AND 64;
UPDATE coupons SET status = DEFAULT, city = country + 1 WHERE amount = 4588 AND note IS NOT NULL;
UPDATE addresses SET email = 18516, amount = city + 1 WHERE city = 2690 AND amount IS NOT NULL;
UPDATE warehouses SET price = 'x@example.com', price = price + 1 WHERE created_at = 3903 AND discount IS NOT NULL;
UPDATE users SET id = 'O''Brien', city = kind + 1 WHERE qty = 2710 AND amount IS NOT NULL;
-- touch order_items
SELECT count(*) FROM order_items WHERE total BETWEEN 6 AND 89;
UPDATE refunds SET note = 658.31, user_id = name + 1 WHERE qty = 4123 AND currency IS NOT NULL;
INSERT INTO carriers (name, id, status, created_at) VALUES ('x@example.com', 514.05, DEFAULT, 91204);
INSERT INTO warehouses (name, country, total, note) VALUES (60487, 'line; with semicolon', NULL, 'O''Brien');
DELETE FROM suppliers WHERE discount < 'EUR' OR amount IN (82, 76, 73, 90, 47);
INSERT INTO shipments (updated_at, amount, total, city) VALUES ('2026-01-09', 26510, 'a b c', 'x@example.com');
DELETE FROM payments WHERE city < 6888 OR total IN (77, 22, 75, 9, 5, 90, 52);
UPDATE subscriptions SET user_id = 94265, price = order_id + 1 WHERE discount = 7227 AND amount IS NOT NULL;
-- touch orders
SELECT count(*) FROM orders WHERE price BETWEEN 30 AND 78;
UPDATE order_items SET product_id = FALSE, currency = id + 1 WHERE user_id = 7279 AND updated_at IS NOT NULL;
DELETE FROM shipments WHERE country < '2026-01-09' OR id IN (74, 74, 50, 58, 60);
DELETE FROM addresses WHERE kind < 967.91 OR discount IN (44, 29, 85);
DELETE FROM products WHERE price < 'pending' OR id IN (3, 14, 77, 95);
INSERT INTO payments (id, email, city, note) VALUES ('O''Brien', 49030, 631.46, 94870);
-- touch categories
SELECT count(*) FROM categories WHERE amount BETWEEN 38 AND 73;
-- touch coupons
SELECT count(*) FROM coupons WHERE qty BETWEEN 5 AND 62;
INSERT INTO subscriptions (total, id, created_at, email) VALUES ('shipped', 41505, 9537, 583.59);
INSERT INTO reviews (note, sku, price, email) VALUES (41185, 7819, 'shipped', 'shipped');
INSERT INTO order_items (total, created_at, discount, kind) VALUES ('a b c', 98562, '2026-01-01', TRUE);
INSERT INTO orders (discount, product_id, note, created_at) VALUES ('line; with semicolon', 'shipped', 796.23, 'shipped');
DELETE FROM sessions WHERE qty < 10993 OR updated_at IN (89, 85, 62, 58, 86, 10, 44);
-- touch suppliers
SELECT count(*) FROM suppliers WHERE discount BETWEEN 2 AND 76;
INSERT INTO inventory (email, discount, order_id, note) VALUES ('O''Brien', 'x@example.com', 149.19, 71918);
UPDATE events SET price = 822.81, created_at = email + 1 WHERE name = 912 AND city IS NOT NULL;
INSERT INTO addresses (order_id, updated_at, city, sku) VALUES ('2026-01-03', 'shipped', 'a b c', TRUE);
DELETE FROM audit_log WHERE qty < TRUE OR email IN (95, 89, 23, 37, 65, 28, 85, 39);
UPDATE carriers SET status = NULL, price = country + 1 WHERE city = 4834 AND id IS NOT NULL;
INSERT INTO payments (note, product_id, qty, country) VALUES (now(), 'pending', 43295, 6259);
INSERT INTO users (sku, price, total, created_at) VALUES (46087, 11833, 50003, TRUE);
INSERT INTO warehouses (sku, email, name, status) VALUES (28326, '2026-01-09', 945.89, 76656);
UPDATE carriers SET currency = NULL, kind = currency + 1 WHERE qty = 2523 AND kind IS NOT NULL;
DELETE FROM warehouses WHERE status < 'line; with semicolon' OR amount IN (61, 81, 27, 77, 73, 65, 40);
UPDATE reviews SET status = '--not a comment', city = created_at + 1 WHERE amount = 4439 AND qty IS NOT NULL;
UPDATE users SET qty = 661.41, order_id = city + 1 WHERE updated_at = 5471 AND updated_at IS NOT NULL;
UPDATE inventory SET total = '--not a comment', qty = total + 1 WHERE qty = 3373 AND created_at IS NOT NULL;
INSERT INTO events (kind, discount, order_id, email) VALUES (825.90, 'shipped', 127.31, 'a b c');
INSERT INTO reviews (price, note, name, created_at) VALUES (now(), 89045, 'x@example.com', 'shipped');
UPDATE audit_log SET order_id = 46904, id = amount + 1 WHERE city = 4698 AND kind IS NOT NULL;
UPDATE orders SET total = 'pending', id = email + 1 WHERE user_id = 4440 AND price IS NOT NULL;
UPDATE invoices SET total = 15179, sku = discount + 1 WHERE id = 514 AND price IS NOT NULL;
INSERT INTO suppliers (country, email, kind, id) VALUES ('EUR', 941.30, 3288, 29577);
INSERT INTO orders (kind, sku, qty, amount) VALUES (now(), 109.49, NULL, NULL);
INSERT INTO payments (discount, kind, user_id, currency) VALUES (709.69, NULL, 88091, 1663);
INSERT INTO warehouses (discount, user_id, note, updated_at) VALUES (58180, 'line; with semicolon', 'line; with semicolon', 982.50);
-- touch users
SELECT count(*) FROM users WHERE email BETWEEN 29 AND 66;
INSERT INTO refunds (order_id, country, product_id, user_id) VALUES (434.25, 'a b c', 70878, 'shipped');
DELETE FROM warehouses WHERE status < NULL OR total IN (94, 4, 45, 43, 42);
UPDATE payments SET product_id = 53819, city = city + 1 WHERE discount = 4956 AND discount IS NOT NULL;
DELETE FROM orders WHERE amount < 59.71 OR note IN (41, 95, 27, 13, 2);
UPDATE suppliers SET kind = 93178, user_id = email + 1 WHERE order_id = 7898 AND sku IS NOT NULL;
-- touch suppliers
SELECT count(*) FROM suppliers WHERE total BETWEEN 29 AND 52;
UPDATE orders SET total = 'line; with semicolon', status = email + 1 WHERE country = 7151 AND user_id IS NOT NULL;
INSERT INTO order_items (note, amount, status, currency) VALUES (99887, 'x@example.com', 24362, 'O''Brien');
UPDATE warehouses SET total = 596.60, product_id = country + 1 WHERE note = 1501 AND product_id IS NOT NULL;
INSERT INTO order_items (sku, kind, discount, country) VALUES (NULL, 'a b c', TRUE, '2026-01-05');
DELETE FROM orders WHERE product_id < 'EUR' OR created_at IN (95, 51, 67, 69, 4, 15, 43, 92);
DELETE FROM order_items WHERE name < 401.68 OR status IN (98, 99, 75, 82, 61);
DELETE FROM addresses WHERE discount < 'O''Brien' OR id IN (27, 19, 23, 91);
UPDATE orders SET qty = 38254, order_id = country + 1 WHERE kind = 7525 AND email IS NOT NULL;
INSERT INTO sessions (currency, price, city, country) VALUES (29892, 'x@example.com', FALSE, 'O''Brien');
INSERT INTO coupons (created_at, sku, price, kind) VALUES ('x@example.com', 'line; with semicolon', 32494, 14247);
-- touch invoices
SELECT count(*) FROM invoices WHERE product_id BETWEEN 19 AND 73;
INSERT INTO warehouses (updated_at, order_id, city, sku) VALUES (629.97, 8655, 19973, 43039);
INSERT INTO events (name, city, user_id, email) VALUES (227.33, 'line; with semicolon', 64.03, 'shipped');
INSERT INTO refunds (total, created_at, country, city) VALUES (394.81, 'shipped', 9971, 27676);
UPDATE payments SET country = 592.84, created_at = discount + 1 WHERE name = 2412 AND discount IS NOT NULL;
DELETE FROM addresses WHERE order_id < 60380 OR city IN (95, 79, 25);
INSERT INTO inventory (price, sku, city, country) VALUES (23494, '2026-01-09', 'x@example.com', 67272);
UPDATE orders SET order_id = 8542, city = currency + 1 WHERE note = 2330 AND city IS NOT NULL;
DELETE FROM refunds WHERE kind < 'shipped' OR country IN (93, 6);
DELETE FROM events WHERE id < DEFAULT OR order_id IN (41, 35);
UPDATE invoices SET currency = 30183, order_id = discount + 1 WHERE discount = 7595 AND user_id IS NOT NULL;
DELETE FROM orders WHERE name < now() OR note IN (24, 67, 23, 74, 37);
UPDATE sessions SET city = 26515, city = updated_at + 1 WHERE total = 5692 AND user_id IS NOT NULL;
INSERT INTO sessions (sku, order_id, discount, name) VALUES (249.62, 'a b c', now(), 'line; with semicolon');
INSERT INTO sessions (updated_at, kind, discount, currency) VALUES (now(), FALSE, 48433, 49176);
INSERT INTO events (product_id, city, order_id, note) VALUES (NULL, TRUE, 77710, '--not a comment');
DELETE FROM reviews WHERE currency < 'pending' OR discount IN (70, 26, 7, 78, 65, 62, 40);
DELETE FROM categories WHERE country < NULL OR amount IN (65, 92, 16, 20);
UPDATE products SET id = 83855, id = amount + 1 WHERE id = 7606 AND created_at IS NOT NULL;
INSERT INTO payments (created_at, sku, country, currency) VALUES ('EUR', '2026-01-09', 8178, '2026-01-04');
UPDATE order_items SET order_id = 435.32, total = city + 1 WHERE note = 8000 AND user_id IS NOT NULL;
INSERT INTO inventory (note, order_id, status, price) VALUES (66405, 'shipped', 'shipped', '2026-01-04');
DELETE FROM inventory WHERE total < '2026-01-08' OR discount IN (42, 7, 34, 39, 13, 73, 36, 6);
DELETE FROM order_items WHERE amount < 6297 OR country IN (54, 29, 91);
-- touch refunds
SELECT count(*) FROM refunds WHERE id BETWEEN 38 AND 90;
UPDATE refunds SET total = 'EUR', id = sku + 1 WHERE id = 3126 AND order_id IS NOT NULL;
UPDATE sessions SET created_at = 55252, country = id + 1 WHERE name = 3359 AND id IS NOT NULL;
INSERT INTO products (order_id, currency, country, city) VALUES (97560, 49516, DEFAULT, 44523);
UPDATE inventory SET amount = 69481, product_id = price + 1 WHERE updated_at = 8967 AND amount IS NOT NULL;
INSERT INTO orders (email, qty, amount, country) VALUES (NULL, 'O''Brien', 97516, 'a b c');
INSERT INTO payments (qty, updated_at, sku, amount) VALUES ('2026-01-01', 59.07, FALSE, NULL);
UPDATE coupons SET name = 29325, id = updated_at + 1 WHERE discount = 7685 AND currency IS NOT NULL;
DELETE FROM subscriptions WHERE currency < 'O''Brien' OR id IN (87, 92);
DELETE FROM subscriptions WHERE currency < 136.58 OR user_id IN (44, 21);
INSERT INTO sessions (created_at, user_id, currency, discount) VALUES (546.09, 94126, 76721, NULL);
INSERT INTO warehouses (price, sku, currency, created_at) VALUES (33756, 93351, 561.28, 31440);
-- touch payments
SELECT count(*) FROM payments WHERE kind BETWEEN 44 AND 82;
DELETE FROM shipments WHERE discount < FALSE OR order_id IN (82, 27, 49, 57);
-- touch subscriptions
SELECT count(*) FROM subscriptions WHERE sku BETWEEN 10 AND 61;
INSERT INTO invoices (user_id, city, created_at, name) VALUES (52700, 396.44, TRUE, '--not a comment');
UPDATE inventory SET note = 31383, qty = price + 1 WHERE discount = 3248 AND name IS NOT NULL;
UPDATE inventory SET total = 'EUR', updated_at = id + 1 WHERE currency = 1417 AND sku IS NOT NULL;
UPDATE reviews SET city = NULL, kind = qty + 1 WHERE amount = 1090 AND discount IS NOT NULL;
UPDATE warehouses SET id = now(), kind = id + 1 WHERE total = 3536 AND kind IS NOT NULL;
DELETE FROM subscriptions WHERE sku < 'shipped' OR discount IN (27, 1, 85, 7, 33, 61, 8, 38);
UPDATE warehouses SET total = NULL, id = country + 1 WHERE product_id = 5566 AND note IS NOT NULL;
UPDATE invoices SET created_at = 26865, note = total + 1 WHERE created_at = 8363 AND updated_at IS NOT NULL;
INSERT INTO payments (product_id, email, discount, name) VALUES (54599, 73033, NULL, NULL);
UPDATE warehouses SET note = 274.39, email = order_id + 1 WHERE status = 7237 AND price IS NOT NULL;
INSERT INTO audit_log (qty, city, amount, discount) VALUES (455.59, 3750, 623.05, 72346);
INSERT INTO reviews (city, updated_at, qty, note) VALUES ('line; with semicolon', 91662, 'EUR', FALSE);
-- touch refunds
SELECT count(*) FROM refunds WHERE total BETWEEN 12 AND 65;
INSERT INTO events (sku, kind, updated_at, discount) VALUES ('2026-01-01', 75263, 324.28, 99358);
UPDATE refunds SET amount = 21878, kind = kind + 1 WHERE name = 3825 AND note IS NOT NULL;
UPDATE events SET id = '--not a comment', name = updated_at + 1 WHERE amount = 392 AND id IS NOT NULL;
UPDATE events SET user_id = 51635, city = name + 1 WHERE price = 4605 AND name IS NOT NULL;
UPDATE categories SET name = 91532, country = total + 1 WHERE price = 5105 AND user_id IS NOT NULL;
INSERT INTO shipments (name, created_at, price, total) VALUES (407.92, 57203, 'a b c', '2026-01-01');
UPDATE addresses SET id = '2026-01-06', country = updated_at + 1 WHERE created_at = 5671 AND email IS NOT NULL;
UPDATE carriers SET email = 392.73, order_id = id + 1 WHERE note = 4668 AND country IS NOT NULL;
INSERT INTO carriers (id, amount, note, qty) VALUES (TRUE, 44578, 13452, 'O''Brien');
-- touch carriers
SELECT count(*) FROM carriers WHERE sku BETWEEN 33 AND 90;
UPDATE refunds SET kind = 72691, updated_at = kind + 1 WHERE product_id = 9777 AND discount IS NOT NULL;
DELETE FROM suppliers WHERE total < 187.27 OR email IN (87, 53);
UPDATE shipments SET sku = TRUE, user_id = price + 1 WHERE id = 6952 AND discount IS NOT NULL;
INSERT INTO categories (price, kind, status, amount) VALUES ('--not a comment', 780.38, now(), 634.88);
UPDATE categories SET updated_at = 67111, status = id + 1 WHERE updated_at = 7032 AND updated_at IS NOT NULL;
INSERT INTO payments (status, currency, amount, email) VALUES (98.40, 84533, 93526, TRUE);
INSERT INTO audit_log (currency, amount, total, kind) VALUES ('--not a comment', 413.76, 'EUR', 23596);
INSERT INTO orders (created_at, user_id, status, updated_at) VALUES (DEFAULT, 21758, 85715, 899.35);
COMMIT;
