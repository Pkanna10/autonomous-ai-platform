"""Benchmark: build a documentation site with Python-Markdown.

    python bench.py           human-readable timing
    python bench.py --json    one JSON line: {"seconds": <best of 3 rounds>}

One round converts every page in bench_data/ with a single Markdown instance
(reset between pages), the way a static-site generator does. The reported
figure is the best round.
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import markdown  # noqa: E402

ROUNDS = 3
EXTENSIONS = ["extra", "toc", "admonition", "meta", "sane_lists", "smarty"]
EXTENSION_CONFIGS = {"toc": {"permalink": True}}


def load_pages():
    data_dir = os.path.join(HERE, "bench_data")
    pages = {}
    for name in sorted(os.listdir(data_dir)):
        with open(os.path.join(data_dir, name), encoding="utf-8") as f:
            pages[name] = f.read()
    return pages


def one_round(pages):
    md = markdown.Markdown(extensions=EXTENSIONS, extension_configs=EXTENSION_CONFIGS)
    start = time.perf_counter()
    size = 0
    for text in pages.values():
        md.reset()
        size += len(md.convert(text))
        size += len(md.toc)
    return time.perf_counter() - start, size


def main():
    pages = load_pages()
    one_round(pages)  # warm-up
    results = [one_round(pages) for _ in range(ROUNDS)]
    best = min(r[0] for r in results)
    if "--json" in sys.argv:
        print(json.dumps({"seconds": best}))
    else:
        size = sum(len(t) for t in pages.values())
        print(f"{len(pages)} pages, {size / 1024:.0f} KiB in, {results[0][1] / 1024:.0f} KiB out: "
              f"best of {ROUNDS} rounds {best * 1000:.0f} ms")


if __name__ == "__main__":
    main()
