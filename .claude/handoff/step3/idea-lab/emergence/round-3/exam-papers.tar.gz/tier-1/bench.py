"""Benchmark: parse the documents in bench_data/ with tomli.

    python bench.py           human-readable timing
    python bench.py --json    one JSON line: {"seconds": <best of 5 rounds>}

One round parses every document once. The reported figure is the best round.
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "src"))

import tomli  # noqa: E402

ROUNDS = 5


def load_documents():
    data_dir = os.path.join(HERE, "bench_data")
    docs = {}
    for name in sorted(os.listdir(data_dir)):
        with open(os.path.join(data_dir, name), encoding="utf-8") as f:
            docs[name] = f.read()
    return docs


def one_round(docs):
    start = time.perf_counter()
    for text in docs.values():
        tomli.loads(text)
    return time.perf_counter() - start


def main():
    docs = load_documents()
    one_round(docs)  # warm-up
    best = min(one_round(docs) for _ in range(ROUNDS))
    if "--json" in sys.argv:
        print(json.dumps({"seconds": best}))
    else:
        size = sum(len(t) for t in docs.values())
        print(f"{len(docs)} documents, {size / 1024:.0f} KiB: best of {ROUNDS} rounds {best * 1000:.1f} ms")


if __name__ == "__main__":
    main()
