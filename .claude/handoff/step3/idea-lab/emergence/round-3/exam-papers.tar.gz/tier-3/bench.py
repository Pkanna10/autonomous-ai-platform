"""Benchmark: render the documents in bench_data/ to HTML with mistune.

    python bench.py           human-readable timing
    python bench.py --json    one JSON line: {"seconds": <best of 3 rounds>}

One round renders every document twice: once with the default renderer
(`mistune.html`) and once with a GitHub-flavoured instance (tables,
strikethrough, footnotes, task lists, bare URLs). The reported figure is the
best round.
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "src"))

import mistune  # noqa: E402

ROUNDS = 3
PLUGINS = ["table", "strikethrough", "footnotes", "task_lists", "url"]


def load_documents():
    data_dir = os.path.join(HERE, "bench_data")
    docs = {}
    for name in sorted(os.listdir(data_dir)):
        with open(os.path.join(data_dir, name), encoding="utf-8") as f:
            docs[name] = f.read()
    return docs


def one_round(docs):
    gfm = mistune.create_markdown(plugins=PLUGINS)
    start = time.perf_counter()
    size = 0
    for text in docs.values():
        size += len(mistune.html(text))
        size += len(gfm(text))
    return time.perf_counter() - start, size


def main():
    docs = load_documents()
    one_round(docs)  # warm-up
    results = [one_round(docs) for _ in range(ROUNDS)]
    best = min(r[0] for r in results)
    if "--json" in sys.argv:
        print(json.dumps({"seconds": best}))
    else:
        size = sum(len(t) for t in docs.values())
        print(f"{len(docs)} documents, {size / 1024:.0f} KiB in, {results[0][1] / 1024:.0f} KiB out: "
              f"best of {ROUNDS} rounds {best * 1000:.0f} ms")


if __name__ == "__main__":
    main()
