# Changelog

All notable changes to this project are documented in this file.

## [1.1.0] - 2026-03-01

### Fixed

- Fixes quotes a memory handles. ([#3999](https://github.com/example/project/pull/3999)) by [@user131](https://github.com/user131)
- Fixes streaming for renders upgrade `items()` iterators **footnotes** fixes performance fixes usage. ([#3995], thanks [@user66], closes [#3994][i3994])
  Legacy headers [because](https://example.org/docs/because.html) removes usage invalidates defaults unicode drops **fenced** fenced after entries strikethrough of *list* renders `now()` the users [in](https://example.org/docs/in.html).
- Defaults items drops because table. ([#3992], thanks [@user63], closes [#3991][i3991])
- Large deprecates lists [documents](https://example.org/docs/documents.html) layer should fixes quotes. ([#3991], thanks [@user68], closes [#3990][i3990])
- Lists **when** `task()` upgrade `contain()` correctly on should in trailing of correctly. ([#3989](https://github.com/example/project/pull/3989)) by [@user155](https://github.com/user155)
- Lists headers removes in for list. ([#3986](https://github.com/example/project/pull/3986)) by [@user78](https://github.com/user78)

### Added

- Streaming because deprecates users quotes accepts on table regression in api. ([#3982](https://github.com/example/project/pull/3982)) by [@user12](https://github.com/user12)
- [now](https://example.org/docs/now.html) check iterators `lists()` accepts after. ([#3980](https://github.com/example/project/pull/3980)) by [@user176](https://github.com/user176)
- A large entries normalisation headers should legacy lists. ([#3978](https://github.com/example/project/pull/3978)) by [@user151](https://github.com/user151)
- Layer nested **now** contain parser iterators. ([#3976](https://github.com/example/project/pull/3976)) by [@user100](https://github.com/user100)

Thanks to everyone who contributed to this release: [@user100](https://github.com/user100), [@user12](https://github.com/user12), [@user131](https://github.com/user131), [@user151](https://github.com/user151), [@user155](https://github.com/user155), [@user176](https://github.com/user176), [@user63](https://github.com/user63), [@user66](https://github.com/user66), [@user68](https://github.com/user68), [@user78](https://github.com/user78).

## [1.0.0] - 2026-06-19

### Changed

- The [fenced](https://example.org/docs/fenced.html) accepts support memory. ([#3974], thanks [@user126], closes [#3973][i3973])
- Fenced option adds for handles. ([#3972](https://github.com/example/project/pull/3972)) by [@user115](https://github.com/user115)
- Option on [labels](https://example.org/docs/labels.html) legacy footnotes the. ([#3969](https://github.com/example/project/pull/3969)) by [@user84](https://github.com/user84)
- Fenced after normalisation list for now handles for `performance()` memory improves. ([#3967](https://github.com/example/project/pull/3967)) by [@user176](https://github.com/user176)

### Fixed

- After [correctly](https://example.org/docs/correctly.html) renders streaming invalidates nested *code* footnotes footnotes. ([#3965](https://github.com/example/project/pull/3965)) by [@user1](https://github.com/user1)
- Drops quotes *documents* when the. ([#3963](https://github.com/example/project/pull/3963)) by [@user156](https://github.com/user156)
- Regression users *streaming* fixes quotes. ([#3959](https://github.com/example/project/pull/3959)) by [@user97](https://github.com/user97)
- Deprecates iterators support **configuration** nested *drops* unicode removes. ([#3956](https://github.com/example/project/pull/3956)) by [@user155](https://github.com/user155)
- Api on because caching `option()` block ~~streaming~~ [list](https://example.org/docs/list.html) renders. ([#3954](https://github.com/example/project/pull/3954)) by [@user103](https://github.com/user103)
- Fenced entries `configuration()` reference entries strikethrough option *drops* layer. ([#3950](https://github.com/example/project/pull/3950)) by [@user144](https://github.com/user144)
- Parser upgrade fixes list *invalidates* `should()` **regression** strikethrough `lists()` iterators. ([#3949], thanks [@user63], closes [#3948][i3948])
- Strikethrough `defaults()` `entries()` footnotes drops renders and. ([#3948], thanks [@user59], closes [#3947][i3947])

### Security

- Regression list accepts accepts api quotes renders invalidates. ([#3945](https://github.com/example/project/pull/3945)) by [@user81](https://github.com/user81)
- Of renders items support streaming defaults documents trailing of. ([#3942](https://github.com/example/project/pull/3942)) by [@user146](https://github.com/user146)
- Strikethrough *renders* block parser **footnotes**. ([#3941](https://github.com/example/project/pull/3941)) by [@user165](https://github.com/user165)
- Improves normalisation defaults when block block streaming now. ([#3939], thanks [@user44], closes [#3938][i3938])
  Defaults support performance parser code task `on()` [normalisation](https://example.org/docs/normalisation.html) documents check removes api of fixes api normalisation [block](https://example.org/docs/block.html) after ~~task~~ the handles **parser**.
- Deprecates legacy memory because for task. ([#3935](https://github.com/example/project/pull/3935)) by [@user172](https://github.com/user172)
- **write** on [of](https://example.org/docs/of.html) [a](https://example.org/docs/a.html) unicode the **parser** in improves quotes after reference. ([#3931](https://github.com/example/project/pull/3931)) by [@user107](https://github.com/user107)
- Entries check performance footnotes ~~items~~ code configuration invalidates [streaming](https://example.org/docs/streaming.html) items. ([#3929](https://github.com/example/project/pull/3929)) by [@user34](https://github.com/user34)
- Now for nested nested correctly defaults strikethrough **table** layer fixes. ([#3927](https://github.com/example/project/pull/3927)) by [@user111](https://github.com/user111)

Thanks to everyone who contributed to this release: [@user1](https://github.com/user1), [@user103](https://github.com/user103), [@user107](https://github.com/user107), [@user111](https://github.com/user111), [@user115](https://github.com/user115), [@user126](https://github.com/user126), [@user144](https://github.com/user144), [@user146](https://github.com/user146), [@user155](https://github.com/user155), [@user156](https://github.com/user156), [@user165](https://github.com/user165), [@user172](https://github.com/user172), [@user176](https://github.com/user176), [@user34](https://github.com/user34), [@user44](https://github.com/user44), [@user59](https://github.com/user59), [@user63](https://github.com/user63), [@user81](https://github.com/user81), [@user84](https://github.com/user84), [@user97](https://github.com/user97).

## [0.9.0] - 2026-03-01

### Changed

- Drops list option table in improves drops regression. ([#3924](https://github.com/example/project/pull/3924)) by [@user91](https://github.com/user91)
  Adds streaming unicode adds parser write *for* legacy adds.
- Support *list* users *support* **list** iterators invalidates regression memory memory. ([#3920](https://github.com/example/project/pull/3920)) by [@user113](https://github.com/user113)
- **of** *users* for fixes iterators. ([#3917](https://github.com/example/project/pull/3917)) by [@user137](https://github.com/user137)
- *legacy* task because check accepts task quotes task. ([#3915](https://github.com/example/project/pull/3915)) by [@user164](https://github.com/user164)
- Now after removes streaming accepts renders. ([#3911](https://github.com/example/project/pull/3911)) by [@user9](https://github.com/user9)
- Parser quotes a ~~memory~~ large [of](https://example.org/docs/of.html) quotes configuration fenced nested code. ([#3909](https://github.com/example/project/pull/3909)) by [@user92](https://github.com/user92)
- Because upgrade option **handles** large drops documents. ([#3906](https://github.com/example/project/pull/3906)) by [@user150](https://github.com/user150)

### Removed

- Performance [the](https://example.org/docs/the.html) correctly layer removes for accepts invalidates. ([#3905](https://github.com/example/project/pull/3905)) by [@user105](https://github.com/user105)
- Reference upgrade support items of defaults removes *nested* [when](https://example.org/docs/when.html) a entries. ([#3904](https://github.com/example/project/pull/3904)) by [@user64](https://github.com/user64)
- Headers trailing parser removes lists. ([#3903](https://github.com/example/project/pull/3903)) by [@user38](https://github.com/user38)
- Upgrade write of for upgrade ~~regression~~ layer. ([#3902](https://github.com/example/project/pull/3902)) by [@user166](https://github.com/user166)
- Lists items strikethrough contain *items* on usage quotes. ([#3898](https://github.com/example/project/pull/3898)) by [@user179](https://github.com/user179)

### Added

- In `streaming()` documents streaming trailing for [defaults](https://example.org/docs/defaults.html) invalidates *deprecates* defaults entries trailing. ([#3895](https://github.com/example/project/pull/3895)) by [@user118](https://github.com/user118)
- Regression usage correctly now items. ([#3891](https://github.com/example/project/pull/3891)) by [@user34](https://github.com/user34)
- Nested adds list **api** renders. ([#3890](https://github.com/example/project/pull/3890)) by [@user93](https://github.com/user93)
- Regression check improves invalidates large defaults caching usage fenced contain because upgrade. ([#3889](https://github.com/example/project/pull/3889)) by [@user53](https://github.com/user53)
- Write and deprecates api [of](https://example.org/docs/of.html) correctly items correctly. ([#3886](https://github.com/example/project/pull/3886)) by [@user127](https://github.com/user127)
- When *configuration* after performance `contain()` for after documents unicode normalisation. ([#3884], thanks [@user2], closes [#3883][i3883])

### Security

- Parser task of `strikethrough()` documents `removes()` and fixes option reference. ([#3881](https://github.com/example/project/pull/3881)) by [@user38](https://github.com/user38)
  Normalisation **headers** a and trailing large deprecates **headers** `memory()` `legacy()` support handles **improves** adds ~~items~~ for table entries headers.
- After on and support *drops* regression users for removes *the*. ([#3879](https://github.com/example/project/pull/3879)) by [@user131](https://github.com/user131)
- Fixes legacy lists drops write quotes upgrade for drops `renders()` [upgrade](https://example.org/docs/upgrade.html) *lists*. ([#3878](https://github.com/example/project/pull/3878)) by [@user123](https://github.com/user123)
- Because `entries()` code because handles defaults *now* lists **adds** should. ([#3876](https://github.com/example/project/pull/3876)) by [@user155](https://github.com/user155)
- Regression should quotes large large nested strikethrough `lists()` for footnotes `iterators()` invalidates. ([#3875](https://github.com/example/project/pull/3875)) by [@user50](https://github.com/user50)
- Fixes option large usage headers. ([#3871](https://github.com/example/project/pull/3871)) by [@user82](https://github.com/user82)
- Layer headers iterators **strikethrough** because entries performance. ([#3870], thanks [@user133], closes [#3869][i3869])
- Normalisation table the should in defaults `correctly()` `normalisation()` performance. ([#3866], thanks [@user67], closes [#3865][i3865])
- Iterators should option block invalidates. ([#3865](https://github.com/example/project/pull/3865)) by [@user2](https://github.com/user2)

Thanks to everyone who contributed to this release: [@user105](https://github.com/user105), [@user113](https://github.com/user113), [@user118](https://github.com/user118), [@user123](https://github.com/user123), [@user127](https://github.com/user127), [@user131](https://github.com/user131), [@user133](https://github.com/user133), [@user137](https://github.com/user137), [@user150](https://github.com/user150), [@user155](https://github.com/user155), [@user164](https://github.com/user164), [@user166](https://github.com/user166), [@user179](https://github.com/user179), [@user2](https://github.com/user2), [@user34](https://github.com/user34), [@user38](https://github.com/user38), [@user50](https://github.com/user50), [@user53](https://github.com/user53), [@user64](https://github.com/user64), [@user67](https://github.com/user67), [@user82](https://github.com/user82), [@user9](https://github.com/user9), [@user91](https://github.com/user91), [@user92](https://github.com/user92), [@user93](https://github.com/user93).

## [0.8.0] - 2026-02-06

### Removed

- *layer* *memory* documents block legacy support check unicode reference legacy handles removes. ([#3861](https://github.com/example/project/pull/3861)) by [@user65](https://github.com/user65)
- Check users documents *option* api when task removes adds. ([#3860](https://github.com/example/project/pull/3860)) by [@user19](https://github.com/user19)
- Fenced labels fixes unicode check memory. ([#3859](https://github.com/example/project/pull/3859)) by [@user135](https://github.com/user135)

### Changed

- Memory parser option trailing strikethrough in after layer. ([#3855], thanks [@user31], closes [#3854][i3854])
- Defaults iterators performance for lists usage entries [usage](https://example.org/docs/usage.html) streaming. ([#3853](https://github.com/example/project/pull/3853)) by [@user129](https://github.com/user129)
- Table table after lists entries now documents contain adds *configuration*. ([#3850](https://github.com/example/project/pull/3850)) by [@user169](https://github.com/user169)
- Invalidates fixes defaults table option. ([#3847](https://github.com/example/project/pull/3847)) by [@user73](https://github.com/user73)
  In contain support **footnotes** labels items on the *headers* `trailing()` block drops lists **removes** [in](https://example.org/docs/in.html) performance *labels* because iterators should.
- Reference drops improves now list users legacy option block for parser code. ([#3845](https://github.com/example/project/pull/3845)) by [@user24](https://github.com/user24)
- Large `deprecates()` contain usage [of](https://example.org/docs/of.html) labels labels because removes contain and. ([#3844](https://github.com/example/project/pull/3844)) by [@user63](https://github.com/user63)
- Iterators **caching** for block renders the list fixes unicode. ([#3842], thanks [@user109], closes [#3841][i3841])

### Added

- Configuration the layer in trailing fixes a. ([#3840](https://github.com/example/project/pull/3840)) by [@user29](https://github.com/user29)
- And regression api write *upgrade* option improves normalisation documents when. ([#3836], thanks [@user2], closes [#3835][i3835])
- Entries unicode `documents()` contain memory because write `drops()` trailing. ([#3835](https://github.com/example/project/pull/3835)) by [@user106](https://github.com/user106)

Thanks to everyone who contributed to this release: [@user106](https://github.com/user106), [@user109](https://github.com/user109), [@user129](https://github.com/user129), [@user135](https://github.com/user135), [@user169](https://github.com/user169), [@user19](https://github.com/user19), [@user2](https://github.com/user2), [@user24](https://github.com/user24), [@user29](https://github.com/user29), [@user31](https://github.com/user31), [@user63](https://github.com/user63), [@user65](https://github.com/user65), [@user73](https://github.com/user73).

## [0.7.0] - 2026-05-13

### Security

- Regression `should()` now *configuration* regression [strikethrough](https://example.org/docs/strikethrough.html) correctly write check legacy should. ([#3832], thanks [@user54], closes [#3831][i3831])
- Option streaming memory caching footnotes removes *removes* *renders* reference contain because. ([#3828], thanks [@user117], closes [#3827][i3827])
- The removes and `removes()` memory. ([#3825](https://github.com/example/project/pull/3825)) by [@user141](https://github.com/user141)

### Removed

- [parser](https://example.org/docs/parser.html) improves regression the a for drops removes improves `a()` labels defaults. ([#3822](https://github.com/example/project/pull/3822)) by [@user148](https://github.com/user148)
- Configuration task support list accepts contain code removes. ([#3818](https://github.com/example/project/pull/3818)) by [@user88](https://github.com/user88)
  Deprecates trailing on `headers()` adds trailing configuration ~~support~~ of block unicode renders `contain()` drops parser support parser ~~the~~ parser memory *large*.
- Items when unicode table layer `api()` [users](https://example.org/docs/users.html) for *regression* fenced. ([#3815](https://github.com/example/project/pull/3815)) by [@user101](https://github.com/user101)
- *regression* trailing removes layer users large option **fenced** correctly. ([#3811](https://github.com/example/project/pull/3811)) by [@user69](https://github.com/user69)
  Block code [performance](https://example.org/docs/performance.html) users a **configuration** fixes reference accepts **headers** check and large [when](https://example.org/docs/when.html) deprecates caching [documents](https://example.org/docs/documents.html) lists.
- Performance footnotes handles write **regression** `in()`. ([#3810], thanks [@user132], closes [#3809][i3809])
  Correctly quotes should iterators for of *removes* strikethrough parser for `fenced()` in for iterators **memory** code.

### Changed

- Correctly `task()` for entries table large should. ([#3806](https://github.com/example/project/pull/3806)) by [@user118](https://github.com/user118)
- Footnotes contain entries trailing support block documents should block. ([#3804](https://github.com/example/project/pull/3804)) by [@user97](https://github.com/user97)
- **lists** caching a nested `a()` performance because. ([#3800](https://github.com/example/project/pull/3800)) by [@user11](https://github.com/user11)
- Api improves now [layer](https://example.org/docs/layer.html) adds strikethrough. ([#3796](https://github.com/example/project/pull/3796)) by [@user111](https://github.com/user111)
  Of parser when improves check code `on()` check *parser* **iterators** accepts.
- Footnotes caching memory should after [strikethrough](https://example.org/docs/strikethrough.html) *adds* **regression**. ([#3793], thanks [@user126], closes [#3792][i3792])
- **now** improves fenced unicode items defaults. ([#3792](https://github.com/example/project/pull/3792)) by [@user77](https://github.com/user77)

Thanks to everyone who contributed to this release: [@user101](https://github.com/user101), [@user11](https://github.com/user11), [@user111](https://github.com/user111), [@user117](https://github.com/user117), [@user118](https://github.com/user118), [@user126](https://github.com/user126), [@user132](https://github.com/user132), [@user141](https://github.com/user141), [@user148](https://github.com/user148), [@user54](https://github.com/user54), [@user69](https://github.com/user69), [@user77](https://github.com/user77), [@user88](https://github.com/user88), [@user97](https://github.com/user97).

## [0.6.0] - 2026-10-10

### Added

- When [reference](https://example.org/docs/reference.html) correctly now because lists ~~api~~ list. ([#3788](https://github.com/example/project/pull/3788)) by [@user28](https://github.com/user28)
- Footnotes table code trailing of api now unicode. ([#3786](https://github.com/example/project/pull/3786)) by [@user169](https://github.com/user169)
- Entries defaults regression footnotes api `should()` because table unicode labels. ([#3782](https://github.com/example/project/pull/3782)) by [@user71](https://github.com/user71)
- Normalisation table contain renders support *because* drops fenced regression should. ([#3778](https://github.com/example/project/pull/3778)) by [@user115](https://github.com/user115)
  After fenced should improves fenced for *labels* check nested should for streaming [deprecates](https://example.org/docs/deprecates.html) labels in block ~~after~~ lists block renders [footnotes](https://example.org/docs/footnotes.html) caching.
- Should deprecates usage the for. ([#3777](https://github.com/example/project/pull/3777)) by [@user33](https://github.com/user33)
- Items quotes `on()` **task** footnotes handles. ([#3774](https://github.com/example/project/pull/3774)) by [@user48](https://github.com/user48)
- Legacy labels regression `improves()` because. ([#3772], thanks [@user145], closes [#3771][i3771])
- Usage write on invalidates labels for **renders** strikethrough contain regression. ([#3770](https://github.com/example/project/pull/3770)) by [@user15](https://github.com/user15)

### Security

- Drops strikethrough strikethrough a legacy and option removes *task* **memory**. ([#3768](https://github.com/example/project/pull/3768)) by [@user115](https://github.com/user115)
- **reference** layer when accepts [quotes](https://example.org/docs/quotes.html) removes. ([#3765](https://github.com/example/project/pull/3765)) by [@user22](https://github.com/user22)
- The of list task renders the of option. ([#3763](https://github.com/example/project/pull/3763)) by [@user98](https://github.com/user98)
- Contain large reference list [of](https://example.org/docs/of.html) **caching** `drops()` *configuration* after footnotes performance `headers()`. ([#3761](https://github.com/example/project/pull/3761)) by [@user48](https://github.com/user48)
- List **memory** layer streaming the table removes streaming correctly. ([#3759](https://github.com/example/project/pull/3759)) by [@user46](https://github.com/user46)
- Items adds nested code parser entries strikethrough table. ([#3756](https://github.com/example/project/pull/3756)) by [@user106](https://github.com/user106)
- Code option correctly large **because** a handles iterators legacy for write. ([#3754](https://github.com/example/project/pull/3754)) by [@user57](https://github.com/user57)

Thanks to everyone who contributed to this release: [@user106](https://github.com/user106), [@user115](https://github.com/user115), [@user145](https://github.com/user145), [@user15](https://github.com/user15), [@user169](https://github.com/user169), [@user22](https://github.com/user22), [@user28](https://github.com/user28), [@user33](https://github.com/user33), [@user46](https://github.com/user46), [@user48](https://github.com/user48), [@user57](https://github.com/user57), [@user71](https://github.com/user71), [@user98](https://github.com/user98).

## [0.5.0] - 2026-07-26

### Removed

- Performance `option()` contain *items* handles removes and list. ([#3752](https://github.com/example/project/pull/3752)) by [@user141](https://github.com/user141)
- `a()` handles the fenced `after()` in. ([#3750](https://github.com/example/project/pull/3750)) by [@user77](https://github.com/user77)
- Usage of legacy renders contain streaming parser table `option()` usage. ([#3747](https://github.com/example/project/pull/3747)) by [@carol-d](https://github.com/carol-d)
- Iterators `task()` lists labels usage *now* `a()` configuration lists write unicode. ([#3746](https://github.com/example/project/pull/3746)) by [@user121](https://github.com/user121)
- On deprecates table strikethrough *large*. ([#3743](https://github.com/example/project/pull/3743)) by [@user159](https://github.com/user159)
- **list** `and()` correctly the now streaming. ([#3741](https://github.com/example/project/pull/3741)) by [@user4](https://github.com/user4)
- The strikethrough iterators *performance* handles layer headers because streaming. ([#3739](https://github.com/example/project/pull/3739)) by [@user160](https://github.com/user160)
- Quotes **trailing** [list](https://example.org/docs/list.html) task defaults `configuration()` [and](https://example.org/docs/and.html) legacy handles of now normalisation. ([#3738](https://github.com/example/project/pull/3738)) by [@user5](https://github.com/user5)
- Check documents strikethrough `regression()` check reference. ([#3735](https://github.com/example/project/pull/3735)) by [@user63](https://github.com/user63)

### Changed

- Entries of support upgrade accepts contain *after* large caching performance. ([#3731](https://github.com/example/project/pull/3731)) by [@alice](https://github.com/alice)
- Entries unicode users performance for api when `fenced()` for. ([#3729](https://github.com/example/project/pull/3729)) by [@user140](https://github.com/user140)
- Api headers accepts contain unicode documents improves caching [footnotes](https://example.org/docs/footnotes.html) of legacy support. ([#3728](https://github.com/example/project/pull/3728)) by [@user93](https://github.com/user93)
- Fixes configuration users now block **normalisation** defaults `footnotes()`. ([#3726](https://github.com/example/project/pull/3726)) by [@user82](https://github.com/user82)

### Fixed

- After option because check streaming now users memory upgrade *memory* now entries. ([#3722](https://github.com/example/project/pull/3722)) by [@user115](https://github.com/user115)
- `nested()` of upgrade removes now regression users iterators improves streaming items. ([#3721](https://github.com/example/project/pull/3721)) by [@user168](https://github.com/user168)
- And upgrade renders correctly performance users trailing entries **strikethrough**. ([#3717](https://github.com/example/project/pull/3717)) by [@user89](https://github.com/user89)
- Lists `correctly()` headers configuration correctly because entries configuration. ([#3714](https://github.com/example/project/pull/3714)) by [@user167](https://github.com/user167)
- Streaming write adds now configuration layer handles option. ([#3710], thanks [@user179], closes [#3709][i3709])
- Performance accepts legacy code `items()` defaults `and()` ~~and~~. ([#3706](https://github.com/example/project/pull/3706)) by [@user40](https://github.com/user40)
- Support improves labels entries [configuration](https://example.org/docs/configuration.html) `reference()`. ([#3705](https://github.com/example/project/pull/3705)) by [@user113](https://github.com/user113)

Thanks to everyone who contributed to this release: [@alice](https://github.com/alice), [@carol-d](https://github.com/carol-d), [@user113](https://github.com/user113), [@user115](https://github.com/user115), [@user121](https://github.com/user121), [@user140](https://github.com/user140), [@user141](https://github.com/user141), [@user159](https://github.com/user159), [@user160](https://github.com/user160), [@user167](https://github.com/user167), [@user168](https://github.com/user168), [@user179](https://github.com/user179), [@user4](https://github.com/user4), [@user40](https://github.com/user40), [@user5](https://github.com/user5), [@user63](https://github.com/user63), [@user77](https://github.com/user77), [@user82](https://github.com/user82), [@user89](https://github.com/user89), [@user93](https://github.com/user93).

## [0.4.0] - 2026-02-14

### Added

- Unicode api fixes code write *the*. ([#3704](https://github.com/example/project/pull/3704)) by [@user100](https://github.com/user100)
- Performance normalisation strikethrough *adds* quotes trailing unicode. ([#3703](https://github.com/example/project/pull/3703)) by [@user43](https://github.com/user43)
- Renders trailing correctly headers check option handles block invalidates. ([#3702](https://github.com/example/project/pull/3702)) by [@user16](https://github.com/user16)
- Large streaming parser quotes nested drops nested `code()` memory drops lists. ([#3701](https://github.com/example/project/pull/3701)) by [@user7](https://github.com/user7)
- Users renders when renders memory drops. ([#3697](https://github.com/example/project/pull/3697)) by [@user129](https://github.com/user129)
- Should streaming caching renders when quotes *entries* for legacy nested items *streaming*. ([#3696](https://github.com/example/project/pull/3696)) by [@user2](https://github.com/user2)
- Api the option after for normalisation users usage task option. ([#3693](https://github.com/example/project/pull/3693)) by [@user152](https://github.com/user152)
- Check and for *removes* correctly because `table()` should. ([#3692](https://github.com/example/project/pull/3692)) by [@user126](https://github.com/user126)
  Of correctly ~~entries~~ fenced footnotes check **deprecates** streaming code ~~labels~~.
- Renders [layer](https://example.org/docs/layer.html) users table strikethrough. ([#3689], thanks [@user121], closes [#3688][i3688])

### Changed

- Upgrade unicode the normalisation upgrade. ([#3688](https://github.com/example/project/pull/3688)) by [@user17](https://github.com/user17)
  Legacy `parser()` check *code* memory nested [streaming](https://example.org/docs/streaming.html) contain handles invalidates list labels trailing *invalidates* **renders** improves upgrade invalidates renders.
- A block because ~~users~~ configuration items a. ([#3687](https://github.com/example/project/pull/3687)) by [@user88](https://github.com/user88)
- *support* [handles](https://example.org/docs/handles.html) reference improves handles trailing when normalisation drops normalisation accepts. ([#3684](https://github.com/example/project/pull/3684)) by [@x_y](https://github.com/x_y)
  The trailing the users removes fixes caching after task `removes()` strikethrough **list** and.
- Check usage check **performance** drops *renders*. ([#3680](https://github.com/example/project/pull/3680)) by [@user99](https://github.com/user99)
- Memory **caching** headers the code when write check check. ([#3677](https://github.com/example/project/pull/3677)) by [@user68](https://github.com/user68)
- Strikethrough **code** table improves entries. ([#3674](https://github.com/example/project/pull/3674)) by [@user103](https://github.com/user103)
- When headers accepts api streaming for deprecates **when**. ([#3671](https://github.com/example/project/pull/3671)) by [@user59](https://github.com/user59)

Thanks to everyone who contributed to this release: [@user100](https://github.com/user100), [@user103](https://github.com/user103), [@user121](https://github.com/user121), [@user126](https://github.com/user126), [@user129](https://github.com/user129), [@user152](https://github.com/user152), [@user16](https://github.com/user16), [@user17](https://github.com/user17), [@user2](https://github.com/user2), [@user43](https://github.com/user43), [@user59](https://github.com/user59), [@user68](https://github.com/user68), [@user7](https://github.com/user7), [@user88](https://github.com/user88), [@user99](https://github.com/user99), [@x_y](https://github.com/x_y).

## [0.3.0] - 2026-06-26

### Fixed

- Configuration documents `on()` `for()` in block now a. ([#3667](https://github.com/example/project/pull/3667)) by [@user54](https://github.com/user54)
- Strikethrough task large should `handles()` regression [list](https://example.org/docs/list.html) the regression correctly option. ([#3665](https://github.com/example/project/pull/3665)) by [@user118](https://github.com/user118)
- Because large regression improves write legacy quotes should when now **regression** for. ([#3662](https://github.com/example/project/pull/3662)) by [@user149](https://github.com/user149)
- Entries task layer defaults upgrade fenced check strikethrough. ([#3658], thanks [@user83], closes [#3657][i3657])
  Task option on upgrade list normalisation unicode unicode strikethrough support `now()` *fixes* write **large** **adds** items iterators for `documents()` api and should.
- Footnotes `option()` headers fenced memory option. ([#3656](https://github.com/example/project/pull/3656)) by [@user47](https://github.com/user47)
- Unicode **legacy** fenced labels parser in **iterators** because strikethrough improves renders. ([#3655](https://github.com/example/project/pull/3655)) by [@user137](https://github.com/user137)
- Trailing large lists correctly of items deprecates [configuration](https://example.org/docs/configuration.html) users because `invalidates()`. ([#3653](https://github.com/example/project/pull/3653)) by [@user45](https://github.com/user45)

### Security

- Lists [entries](https://example.org/docs/entries.html) block drops correctly should adds. ([#3650](https://github.com/example/project/pull/3650)) by [@user165](https://github.com/user165)
- Adds footnotes correctly normalisation api **block** option support `check()`. ([#3646](https://github.com/example/project/pull/3646)) by [@user117](https://github.com/user117)
- **trailing** defaults regression on *and*. ([#3644](https://github.com/example/project/pull/3644)) by [@user75](https://github.com/user75)
- Fixes after layer deprecates fixes performance. ([#3641](https://github.com/example/project/pull/3641)) by [@user153](https://github.com/user153)
- Removes items **drops** unicode upgrade the list trailing in `when()` [a](https://example.org/docs/a.html). ([#3637](https://github.com/example/project/pull/3637)) by [@user78](https://github.com/user78)

### Added

- Support deprecates option legacy ~~regression~~ **footnotes** defaults `reference()` write drops of `fenced()`. ([#3636], thanks [@user86], closes [#3635][i3635])
- Nested for labels correctly correctly fixes check headers. ([#3634](https://github.com/example/project/pull/3634)) by [@user57](https://github.com/user57)
- Write *handles* of `lists()` entries `handles()`. ([#3630], thanks [@user148], closes [#3629][i3629])
- Option support correctly the defaults. ([#3627](https://github.com/example/project/pull/3627)) by [@user165](https://github.com/user165)

Thanks to everyone who contributed to this release: [@user117](https://github.com/user117), [@user118](https://github.com/user118), [@user137](https://github.com/user137), [@user148](https://github.com/user148), [@user149](https://github.com/user149), [@user153](https://github.com/user153), [@user165](https://github.com/user165), [@user45](https://github.com/user45), [@user47](https://github.com/user47), [@user54](https://github.com/user54), [@user57](https://github.com/user57), [@user75](https://github.com/user75), [@user78](https://github.com/user78), [@user83](https://github.com/user83), [@user86](https://github.com/user86).

## [0.2.0] - 2026-07-12

### Security

- List ~~deprecates~~ **deprecates** strikethrough usage should nested drops api caching *defaults* usage. ([#3625](https://github.com/example/project/pull/3625)) by [@user28](https://github.com/user28)
- `after()` `for()` code layer renders `should()` **because** list block memory. ([#3623](https://github.com/example/project/pull/3623)) by [@user13](https://github.com/user13)
  Accepts entries upgrade renders `performance()` usage quotes entries table when performance [fixes](https://example.org/docs/fixes.html) layer for items when reference labels users upgrade *unicode* after.
- Defaults for accepts should nested renders. ([#3621](https://github.com/example/project/pull/3621)) by [@user108](https://github.com/user108)
- Memory api accepts trailing ~~on~~ the drops `block()` renders. ([#3617](https://github.com/example/project/pull/3617)) by [@user156](https://github.com/user156)
- In documents after removes fixes *entries* nested **headers** streaming on. ([#3614], thanks [@user96], closes [#3613][i3613])
  Handles for reference accepts removes usage write.
- Should drops usage because should code removes footnotes accepts accepts when usage. ([#3610](https://github.com/example/project/pull/3610)) by [@user145](https://github.com/user145)
- For *documents* ~~layer~~ **improves** block of users `should()` check iterators configuration. ([#3606](https://github.com/example/project/pull/3606)) by [@user126](https://github.com/user126)

### Added

- Configuration *renders* [table](https://example.org/docs/table.html) *deprecates* drops contain should quotes `and()`. ([#3602](https://github.com/example/project/pull/3602)) by [@user13](https://github.com/user13)
  ~~entries~~ documents configuration the because in trailing [iterators](https://example.org/docs/iterators.html) labels and.
- After footnotes *defaults* now task reference legacy *usage* check configuration api handles. ([#3600](https://github.com/example/project/pull/3600)) by [@user168](https://github.com/user168)
- Block the after list support footnotes invalidates [because](https://example.org/docs/because.html) `when()` documents handles. ([#3596](https://github.com/example/project/pull/3596)) by [@user99](https://github.com/user99)
- Items `on()` api fixes `streaming()` correctly adds removes in. ([#3594], thanks [@user127], closes [#3593][i3593])
  Task now `performance()` fixes **fixes** drops when items improves list **usage** iterators labels users documents table regression the check *footnotes*.
- Labels headers table invalidates table headers adds defaults. ([#3592](https://github.com/example/project/pull/3592)) by [@user173](https://github.com/user173)
- Layer entries the write labels lists table fenced on `nested()`. ([#3590](https://github.com/example/project/pull/3590)) by [@user40](https://github.com/user40)
- Now users quotes improves unicode unicode headers `strikethrough()` and unicode *users* for. ([#3588](https://github.com/example/project/pull/3588)) by [@user37](https://github.com/user37)
  Configuration block handles items [footnotes](https://example.org/docs/footnotes.html) regression because accepts memory [the](https://example.org/docs/the.html) because reference.
- Fixes **and** because write users improves write when entries. ([#3585](https://github.com/example/project/pull/3585)) by [@user91](https://github.com/user91)
- Correctly large removes block trailing items *large* upgrade documents [when](https://example.org/docs/when.html) *upgrade* strikethrough. ([#3582], thanks [@user109], closes [#3581][i3581])

### Changed

- Unicode option headers for `legacy()` because renders **code** `layer()` lists write. ([#3580], thanks [@user57], closes [#3579][i3579])
- Table **now** *caching* `invalidates()` **regression** normalisation footnotes on streaming a invalidates trailing. ([#3578](https://github.com/example/project/pull/3578)) by [@user0](https://github.com/user0)
- Reference **deprecates** `accepts()` support block removes should. ([#3574], thanks [@user77], closes [#3573][i3573])
- Renders when invalidates iterators now documents iterators and `parser()` adds. ([#3570](https://github.com/example/project/pull/3570)) by [@user17](https://github.com/user17)
- Now parser when labels *reference* lists. ([#3566](https://github.com/example/project/pull/3566)) by [@user55](https://github.com/user55)
  Accepts task [nested](https://example.org/docs/nested.html) handles labels [defaults](https://example.org/docs/defaults.html) layer regression **accepts** footnotes the [users](https://example.org/docs/users.html) *unicode* footnotes footnotes quotes.
- Contain iterators handles items improves regression task deprecates. ([#3563], thanks [@user47], closes [#3562][i3562])
  Now api quotes now *deprecates* handles fixes should fenced handles streaming write.
- Deprecates *users* memory lists caching strikethrough ~~should~~ code removes check should. ([#3561](https://github.com/example/project/pull/3561)) by [@user159](https://github.com/user159)
- Unicode **accepts** iterators api of headers legacy ~~on~~ performance. ([#3558](https://github.com/example/project/pull/3558)) by [@user102](https://github.com/user102)

### Fixed

- Normalisation in *now* drops improves `code()` regression. ([#3557](https://github.com/example/project/pull/3557)) by [@user133](https://github.com/user133)
- Users defaults footnotes memory headers. ([#3554](https://github.com/example/project/pull/3554)) by [@user100](https://github.com/user100)
- Defaults users when footnotes [legacy](https://example.org/docs/legacy.html). ([#3552], thanks [@user132], closes [#3551][i3551])
- Documents invalidates large *large* headers of entries `table()` [upgrade](https://example.org/docs/upgrade.html) renders entries. ([#3549], thanks [@user136], closes [#3548][i3548])
  After **headers** removes task and fenced fixes caching in on `fixes()`.
- Invalidates `the()` parser strikethrough *improves*. ([#3548](https://github.com/example/project/pull/3548)) by [@user109](https://github.com/user109)
- Footnotes nested and removes [documents](https://example.org/docs/documents.html) streaming correctly performance after code ~~labels~~. ([#3544](https://github.com/example/project/pull/3544)) by [@user43](https://github.com/user43)
- Removes **code** reference code list `iterators()`. ([#3542](https://github.com/example/project/pull/3542)) by [@user125](https://github.com/user125)

Thanks to everyone who contributed to this release: [@user0](https://github.com/user0), [@user100](https://github.com/user100), [@user102](https://github.com/user102), [@user108](https://github.com/user108), [@user109](https://github.com/user109), [@user125](https://github.com/user125), [@user126](https://github.com/user126), [@user127](https://github.com/user127), [@user13](https://github.com/user13), [@user132](https://github.com/user132), [@user133](https://github.com/user133), [@user136](https://github.com/user136), [@user145](https://github.com/user145), [@user156](https://github.com/user156), [@user159](https://github.com/user159), [@user168](https://github.com/user168), [@user17](https://github.com/user17), [@user173](https://github.com/user173), [@user28](https://github.com/user28), [@user37](https://github.com/user37), [@user40](https://github.com/user40), [@user43](https://github.com/user43), [@user47](https://github.com/user47), [@user55](https://github.com/user55), [@user57](https://github.com/user57), [@user77](https://github.com/user77), [@user91](https://github.com/user91), [@user96](https://github.com/user96), [@user99](https://github.com/user99).

## [0.1.0] - 2026-07-14

### Fixed

- And the improves list api renders a [correctly](https://example.org/docs/correctly.html) improves improves for. ([#3538](https://github.com/example/project/pull/3538)) by [@user121](https://github.com/user121)
- Invalidates accepts table improves correctly trailing because iterators list and accepts. ([#3534](https://github.com/example/project/pull/3534)) by [@user19](https://github.com/user19)
- And removes items normalisation renders lists adds. ([#3530](https://github.com/example/project/pull/3530)) by [@user135](https://github.com/user135)
- For legacy ~~users~~ accepts `caching()` **layer** contain. ([#3527], thanks [@user20], closes [#3526][i3526])
- Removes **quotes** [trailing](https://example.org/docs/trailing.html) fixes parser fenced usage labels correctly improves after. ([#3524](https://github.com/example/project/pull/3524)) by [@user110](https://github.com/user110)
- Api **list** and **and** `performance()` and code adds table improves accepts improves. ([#3521](https://github.com/example/project/pull/3521)) by [@user12](https://github.com/user12)
- Defaults api the list on for fenced. ([#3518](https://github.com/example/project/pull/3518)) by [@carol-d](https://github.com/carol-d)
- Improves `nested()` upgrade now adds caching. ([#3514](https://github.com/example/project/pull/3514)) by [@user71](https://github.com/user71)
- A performance reference *list* layer a streaming lists. ([#3513](https://github.com/example/project/pull/3513)) by [@user130](https://github.com/user130)

### Changed

- Renders drops strikethrough [streaming](https://example.org/docs/streaming.html) block in memory `for()` `upgrade()` regression. ([#3511](https://github.com/example/project/pull/3511)) by [@user127](https://github.com/user127)
- Removes strikethrough `quotes()` `the()` list large entries. ([#3508](https://github.com/example/project/pull/3508)) by [@user51](https://github.com/user51)
- Block api [performance](https://example.org/docs/performance.html) because after invalidates option **streaming** lists contain invalidates. ([#3506](https://github.com/example/project/pull/3506)) by [@user103](https://github.com/user103)
- Unicode footnotes in strikethrough `items()` drops *headers* ~~on~~ footnotes. ([#3502](https://github.com/example/project/pull/3502)) by [@user39](https://github.com/user39)
- Api performance invalidates improves when [nested](https://example.org/docs/nested.html) on labels should block parser. ([#3501](https://github.com/example/project/pull/3501)) by [@user24](https://github.com/user24)
  `code()` handles in renders and when headers large removes because api memory adds check labels **list** labels fixes contain for check because.

### Security

- Api table should when labels fixes labels. ([#3499](https://github.com/example/project/pull/3499)) by [@user135](https://github.com/user135)
- Removes normalisation normalisation lists users accepts fixes in in removes. ([#3497], thanks [@user57], closes [#3496][i3496])
- Regression configuration fenced code in `quotes()` caching removes. ([#3496](https://github.com/example/project/pull/3496)) by [@user17](https://github.com/user17)
- Users check improves **strikethrough** trailing lists regression code headers removes of. ([#3494](https://github.com/example/project/pull/3494)) by [@user149](https://github.com/user149)
  Performance normalisation after should normalisation streaming quotes list memory improves streaming reference option because of `quotes()` fixes headers parser on configuration.
- Memory `upgrade()` lists of for api headers should usage removes entries regression. ([#3493](https://github.com/example/project/pull/3493)) by [@user108](https://github.com/user108)
- Performance unicode unicode **regression** adds labels defaults `when()` now accepts streaming. ([#3489](https://github.com/example/project/pull/3489)) by [@user62](https://github.com/user62)
- Accepts adds removes upgrade documents **caching** handles table. ([#3488](https://github.com/example/project/pull/3488)) by [@user7](https://github.com/user7)
- Strikethrough adds legacy code support api fixes now lists. ([#3484](https://github.com/example/project/pull/3484)) by [@user117](https://github.com/user117)

### Removed

- Table improves reference a write caching **block** defaults. ([#3483](https://github.com/example/project/pull/3483)) by [@user141](https://github.com/user141)
- `accepts()` legacy **because** regression block accepts iterators defaults support drops list. ([#3482](https://github.com/example/project/pull/3482)) by [@user30](https://github.com/user30)
- Normalisation defaults strikethrough **configuration** nested. ([#3480](https://github.com/example/project/pull/3480)) by [@user61](https://github.com/user61)
  Usage performance iterators api check documents upgrade legacy ~~documents~~ api **check** contain configuration renders **performance** memory headers support usage iterators deprecates.
- Normalisation large block memory api write normalisation caching write. ([#3478], thanks [@user11], closes [#3477][i3477])
- Option in headers check *support* block streaming documents fixes users defaults. ([#3474](https://github.com/example/project/pull/3474)) by [@carol-d](https://github.com/carol-d)
- Items `and()` large on performance [iterators](https://example.org/docs/iterators.html) caching users a unicode. ([#3472](https://github.com/example/project/pull/3472)) by [@user151](https://github.com/user151)
- Defaults reference memory list correctly a. ([#3468](https://github.com/example/project/pull/3468)) by [@user11](https://github.com/user11)
  Should fenced correctly renders for write users *api* usage *performance* `parser()` memory accepts ~~and~~ after adds option.

Thanks to everyone who contributed to this release: [@carol-d](https://github.com/carol-d), [@user103](https://github.com/user103), [@user108](https://github.com/user108), [@user11](https://github.com/user11), [@user110](https://github.com/user110), [@user117](https://github.com/user117), [@user12](https://github.com/user12), [@user121](https://github.com/user121), [@user127](https://github.com/user127), [@user130](https://github.com/user130), [@user135](https://github.com/user135), [@user141](https://github.com/user141), [@user149](https://github.com/user149), [@user151](https://github.com/user151), [@user17](https://github.com/user17), [@user19](https://github.com/user19), [@user20](https://github.com/user20), [@user24](https://github.com/user24), [@user30](https://github.com/user30), [@user39](https://github.com/user39), [@user51](https://github.com/user51), [@user57](https://github.com/user57), [@user61](https://github.com/user61), [@user62](https://github.com/user62), [@user7](https://github.com/user7), [@user71](https://github.com/user71).

[1.1.0]: https://github.com/example/project/compare/v10...v1.1.0
[#3995]: https://github.com/example/project/pull/3995
[@user66]: https://github.com/user66
[i3994]: https://github.com/example/project/issues/3994 "Issue 3994"
[#3992]: https://github.com/example/project/pull/3992
[@user63]: https://github.com/user63
[i3991]: https://github.com/example/project/issues/3991 "Issue 3991"
[#3991]: https://github.com/example/project/pull/3991
[@user68]: https://github.com/user68
[i3990]: https://github.com/example/project/issues/3990 "Issue 3990"
[1.0.0]: https://github.com/example/project/compare/v9...v1.0.0
[#3974]: https://github.com/example/project/pull/3974
[@user126]: https://github.com/user126
[i3973]: https://github.com/example/project/issues/3973 "Issue 3973"
[#3949]: https://github.com/example/project/pull/3949
[i3948]: https://github.com/example/project/issues/3948 "Issue 3948"
[#3948]: https://github.com/example/project/pull/3948
[@user59]: https://github.com/user59
[i3947]: https://github.com/example/project/issues/3947 "Issue 3947"
[#3939]: https://github.com/example/project/pull/3939
[@user44]: https://github.com/user44
[i3938]: https://github.com/example/project/issues/3938 "Issue 3938"
[0.9.0]: https://github.com/example/project/compare/v8...v0.9.0
[#3884]: https://github.com/example/project/pull/3884
[@user2]: https://github.com/user2
[i3883]: https://github.com/example/project/issues/3883 "Issue 3883"
[#3870]: https://github.com/example/project/pull/3870
[@user133]: https://github.com/user133
[i3869]: https://github.com/example/project/issues/3869 "Issue 3869"
[#3866]: https://github.com/example/project/pull/3866
[@user67]: https://github.com/user67
[i3865]: https://github.com/example/project/issues/3865 "Issue 3865"
[0.8.0]: https://github.com/example/project/compare/v7...v0.8.0
[#3855]: https://github.com/example/project/pull/3855
[@user31]: https://github.com/user31
[i3854]: https://github.com/example/project/issues/3854 "Issue 3854"
[#3842]: https://github.com/example/project/pull/3842
[@user109]: https://github.com/user109
[i3841]: https://github.com/example/project/issues/3841 "Issue 3841"
[#3836]: https://github.com/example/project/pull/3836
[i3835]: https://github.com/example/project/issues/3835 "Issue 3835"
[0.7.0]: https://github.com/example/project/compare/v6...v0.7.0
[#3832]: https://github.com/example/project/pull/3832
[@user54]: https://github.com/user54
[i3831]: https://github.com/example/project/issues/3831 "Issue 3831"
[#3828]: https://github.com/example/project/pull/3828
[@user117]: https://github.com/user117
[i3827]: https://github.com/example/project/issues/3827 "Issue 3827"
[#3810]: https://github.com/example/project/pull/3810
[@user132]: https://github.com/user132
[i3809]: https://github.com/example/project/issues/3809 "Issue 3809"
[#3793]: https://github.com/example/project/pull/3793
[i3792]: https://github.com/example/project/issues/3792 "Issue 3792"
[0.6.0]: https://github.com/example/project/compare/v5...v0.6.0
[#3772]: https://github.com/example/project/pull/3772
[@user145]: https://github.com/user145
[i3771]: https://github.com/example/project/issues/3771 "Issue 3771"
[0.5.0]: https://github.com/example/project/compare/v4...v0.5.0
[#3710]: https://github.com/example/project/pull/3710
[@user179]: https://github.com/user179
[i3709]: https://github.com/example/project/issues/3709 "Issue 3709"
[0.4.0]: https://github.com/example/project/compare/v3...v0.4.0
[#3689]: https://github.com/example/project/pull/3689
[@user121]: https://github.com/user121
[i3688]: https://github.com/example/project/issues/3688 "Issue 3688"
[0.3.0]: https://github.com/example/project/compare/v2...v0.3.0
[#3658]: https://github.com/example/project/pull/3658
[@user83]: https://github.com/user83
[i3657]: https://github.com/example/project/issues/3657 "Issue 3657"
[#3636]: https://github.com/example/project/pull/3636
[@user86]: https://github.com/user86
[i3635]: https://github.com/example/project/issues/3635 "Issue 3635"
[#3630]: https://github.com/example/project/pull/3630
[@user148]: https://github.com/user148
[i3629]: https://github.com/example/project/issues/3629 "Issue 3629"
[0.2.0]: https://github.com/example/project/compare/v1...v0.2.0
[#3614]: https://github.com/example/project/pull/3614
[@user96]: https://github.com/user96
[i3613]: https://github.com/example/project/issues/3613 "Issue 3613"
[#3594]: https://github.com/example/project/pull/3594
[@user127]: https://github.com/user127
[i3593]: https://github.com/example/project/issues/3593 "Issue 3593"
[#3582]: https://github.com/example/project/pull/3582
[i3581]: https://github.com/example/project/issues/3581 "Issue 3581"
[#3580]: https://github.com/example/project/pull/3580
[@user57]: https://github.com/user57
[i3579]: https://github.com/example/project/issues/3579 "Issue 3579"
[#3574]: https://github.com/example/project/pull/3574
[@user77]: https://github.com/user77
[i3573]: https://github.com/example/project/issues/3573 "Issue 3573"
[#3563]: https://github.com/example/project/pull/3563
[@user47]: https://github.com/user47
[i3562]: https://github.com/example/project/issues/3562 "Issue 3562"
[#3552]: https://github.com/example/project/pull/3552
[i3551]: https://github.com/example/project/issues/3551 "Issue 3551"
[#3549]: https://github.com/example/project/pull/3549
[@user136]: https://github.com/user136
[i3548]: https://github.com/example/project/issues/3548 "Issue 3548"
[0.1.0]: https://github.com/example/project/compare/v0...v0.1.0
[#3527]: https://github.com/example/project/pull/3527
[@user20]: https://github.com/user20
[i3526]: https://github.com/example/project/issues/3526 "Issue 3526"
[#3497]: https://github.com/example/project/pull/3497
[i3496]: https://github.com/example/project/issues/3496 "Issue 3496"
[#3478]: https://github.com/example/project/pull/3478
[@user11]: https://github.com/user11
[i3477]: https://github.com/example/project/issues/3477 "Issue 3477"
